const { Schema, model } = require("mongoose");

const userset = new Schema({

    guildID: { type: String },
    loja: { type: String },
    publica: { type: String },
    privada: { type: String },
    carrinhos: { type: String },
    termos: { type: String },
    privada: { type: String },
    acesstoken: { type: String },
});

module.exports = model("loja", userset);
