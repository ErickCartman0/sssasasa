const { Schema, model } = require("mongoose");

const userset = new Schema({

    channelId: { type: String },
    idCompra: { type: String },
    bodyCompra: { type: String },
    produtos: { type: String, default:null },
    user: { type: String },
    status: { type: String },
    produto: { type: String },
    valor: { type: String },
    valororiginal: { type: String },
    cupom: { type: String },
    quantidade: { type: String },
});

module.exports = model("compras", userset);
