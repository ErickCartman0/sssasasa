const { Schema, model } = require("mongoose");

const userset = new Schema({

    data: { type: String },
    valor: { type: Number },
    produtos: { type: Number },

});

module.exports = model("vendas", userset);
