const { Schema, model } = require("mongoose");

const userset = new Schema({
  userID: { type: String },
  valor: { type: String },
  produtos: { type: String },  
  perm: { type: Boolean },  
  termos: { type: Boolean },  

});

module.exports = model("users", userset);
