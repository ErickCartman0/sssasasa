const { Schema, model } = require("mongoose");

const userset = new Schema({
  nome: { type: String },
  desc: { type: String, default:0 },
  valor: { type: String, default:0 },
  banner: { type: String, default:0 },
  type:{ type: String, default:1 },
  msgs:{ type: Array },
  estoque: { type: Array },
});

module.exports = model("produtos", userset);
