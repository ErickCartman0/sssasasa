const { Schema, model } = require("mongoose");

const userset = new Schema({

    nome: { type: String },
    quantidade: { type: Number },
    porcentagem: { type: Number },
    produto: { type: String,default:null },
    valormin: { type: Number, default:0 },

});

module.exports = model("cupom", userset);
