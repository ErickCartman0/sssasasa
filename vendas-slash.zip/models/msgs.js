const { Schema, model } = require("mongoose");

const userset = new Schema({

    msgId: { type: String },
    nome: { type: String },

});

module.exports = model("type", userset);
