const Client = require('../index').Client
const Discord = require('discord.js')
const config = require('../config.json')
const mongo = require("mongoose");
const compra = require("../models/compras")
const mercadopago = require("mercadopago");
const loja = require('../models/loja');
const produtos = require('../models/produtos');
const vendas = require('../models/vendas');
const User= require("../models/User")
Client.on('ready', async(client) => {

setInterval(async()=>{
    let compras = await compra.find({status:'pendente'})
    compras.forEach(async value=>{
    
        let vds = await vendas.findOne({data:new Date().toLocaleDateString()})
        let produ = await produtos.findOne({nome:value.produto})
        let channel = await client.channels.cache.get(value.channelId)
        if(!channel) return compra.updateOne({channelId:value.channelId},{$set:{status:'cancelado'}})

        if(value.bodyCompra !== null) {
           
            let lg = await loja.findOne({ guildID: channel.guild.id });
            mercadopago.configurations.setAccessToken(lg.acesstoken);
            mercadopago.payment.capture(value.bodyCompra, mercadopago, async (error, response) => {
                if (error){
       
                    
                } else{
                    if(produ.type == '1') {
             
                        let est = produ.estoque
                        if(est.length < (Number(compra.quantidade))) return channel.send({embeds:[new Discord.EmbedBuilder().setDescription(`Ouve um erro em meu estoque, parece que tropecei e cai...\n\nPasse o id da sua compra para staff e receba seu produto.\n> Id da compra: ${value.bodyCompra}`).setColor("#FFF")],content:`<@${value.user}>`})
            
                        let ds = Number(value.quantidade)
                        let cdmdaqf = est.splice(0,ds)

                        idx= '';
                        cdmdaqf.map(val=>{idx+=`\n${val}`})
                   
                        let user = client.users.cache.get(value.user)
               
                        if(!vds) { await vendas.create({data:new Date().toLocaleDateString(),valor:0,produtos:0});vds = await vendas.findOne({data:new Date().toLocaleDateString()}) }
                        await  produtos.updateOne({nome:value.produto},{$set:{estoque:est}})
               
                             await vendas.updateOne({data:new Date().toLocaleDateString()},{$set:{valor:Number(value.valor)+vds.valor,produtos:Number(value.quantidade)+vds.produtos}})
                            await  User.updateOne({userId:value.user},{$set:{valor:Number(value.valor),produtos:Number(value.quantidade)}})
                            await compra.updateOne({channelId:channel.id},{$set:{status:"pago",produtos:idx}})
                       
                       {
                       let database = await produtos.findOne({nome:value.produto})
            
          
                        let embed = new Discord.EmbedBuilder()
                        .setAuthor({name:inter.guild.name, iconURL:inter.guild.iconURL()})
                        .setDescription(`\`\`\`${database.desc}\`\`\`\n**💻 - Nome: ${database.nome}**\n**💎 - Preço: R$${database.valor}**\n**📦 - Estoque: ${database.estoque.length}**`)
                        .setImage(database.banner)
                        .setColor("#fff")
                        .setFooter({text:`Utima atualização`})
                        .setTimestamp()
            
                        let row = new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                            .setCustomId("Comprar")
                            .setLabel("Comprar")
                            .setStyle(Discord.ButtonStyle.Primary)
                        )

              i.deferUpdate()
                        
                 let msgs = await    database.msgs
                msgs.forEach(async val=>{
                    await Client.channels.cache.get(val.split("_")[0]).messages.fetch(val.split("_")[1]).then(msg=>{
                        msg.edit({embeds:[embed],components:[row]})
                    }).catch(err=>{return})
                })
                       }
                        user.send({embeds:[new Discord.EmbedBuilder().setDescription(`💎 Produto: ${value.produto}\n\n📗 Valor: ${value.valor}\n💻 Quantidade: ${value.quantidade}\n💘 Id da compra: ${value.bodyCompra}\n\n💥 Seus Produtos: \`\`\`${idx}\`\`\``).setColor("#FFF") ]}).then( ()=>{
                           
                 
                            channel.send({content:user.toString()+' Avalie de 1 a 5 seu produto e atendimento.\n> Você tem apenas 30s',components:[new Discord.ActionRowBuilder().addComponents(

                                new Discord.ButtonBuilder()
                                .setCustomId(`A_1`)
                                .setLabel(`1`)
                                .setStyle(Discord.ButtonStyle.Secondary),
                            
                            
                                new Discord.ButtonBuilder()
                                .setCustomId(`A_2`)
                                .setLabel(`2`)
                                .setStyle(Discord.ButtonStyle.Secondary),
                            
                            
                                new Discord.ButtonBuilder()
                                .setCustomId(`A_3`)
                                .setLabel(`3`)
                                .setStyle(Discord.ButtonStyle.Secondary),
                            
                            
                                new Discord.ButtonBuilder()
                                .setCustomId(`A_4`)
                                .setLabel(`4`)
                                .setStyle(Discord.ButtonStyle.Secondary),
                            
                            
                                new Discord.ButtonBuilder()
                                .setCustomId(`A_5`)
                                .setLabel(`5`)
                                .setStyle(Discord.ButtonStyle.Secondary),


                            )]}).then(msg=>{
                                const {ComponentType} = require("discord.js")
                                const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 30000 });
                                function sendlogs (avaliacao) {
                                    Client.channels.cache.get(lg.publica).send({embeds:[new Discord.EmbedBuilder().setAuthor({name:user.username,iconURL:user.avatarURL()}).setDescription(`👦 User: ${user}(${user.id})\n💎 Produto: ${value.produto}\n💙 Cupom: ${value.cupom || "nenhum"}\n📗 Valor: ${value.valor}\n💻 Quantidade: ${value.quantidade}\n⭐ Avaliação: ${avaliacao}`).setColor("#FFF") ]})
                                    Client.channels.cache.get(lg.privada).send({embeds:[new Discord.EmbedBuilder().setAuthor({name:user.username,iconURL:user.avatarURL()}).setDescription(`👦 User: ${user}(${user.id})\n💎 Produto: ${value.produto}\n💙 Cupom: ${value.cupom || "nenhum"}\n📗 Valor: ${value.valor}\n💻 Quantidade: ${value.quantidade}\n⭐ Avaliação: ${avaliacao}\n💘 Id da compra: ${value.bodyCompra}\n\n💥 Produtos: \`\`\`${idx}\`\`\``).setColor("#FFF") ]})
                                }
                                collector.on('collect', async i => {
                                    if (i.user.id === user.id) {
                                        i.deferUpdate()
                                     
                                      
                                    
                                        collector.stop()
                                     
                                   
                                    }
                                })
                                
collector.on('end', collected => {
let value = collected.map(val=>val)
channel.delete()
if(!value || value.length < 1) return    sendlogs('Não avaliado')
 
    let avaliacao = value[0].customId.split("_")[1]
    sendlogs(avaliacao)
})
                            })
               
                
                        }).catch(async err=>{
                         
                            await compra.updateOne({channelId:channel.id},{$set:{status:"erro ao entregar"}})
                           channel.send({ embeds:[new Discord.EmbedBuilder().setDescription(`Parece que sua dm estava bloqueada, alerte a staff e passe o id da compra pra receber seus produtos\n> Id da compra: ${value.bodyCompra}`).setColor("#FFF") ]})
                        })
                       
                    } 
                }
            }).catch(err=>{return console.log(err) })
        }
    })
},5000)


})

