const Client = require("../index").Client
const Discord = require('discord.js')
const produtos = require("../models/produtos")
const lm = require("../models/msgs")
const loja = require("../models/loja")
const users = require("../models/User")
const compras = require("../models/compras")
const cupom = require("../models/cupom")
const mercadopago = require("mercadopago")
Client.on('interactionCreate', async inter => {

    if (inter.isButton()) {
        switch (inter.customId) {
            case 'Comprar': {
                let datas = {
                    loja: await loja.findOne({ guildID: inter.guild.id }),
                    user: await users.findOne({ userID: inter.user.id }),
                    msg: await lm.findOne({ msgId: inter.message.id })
                }
                datas.produto = await produtos.findOne({ nome: datas.msg.nome })
                if (!datas.user) { await users.create({ userID: inter.user.id, valor: 0, produtos: 0, perm: false, termos: false }); datas.user = await users.findOne({ userID: inter.user.id }) }
                if (!datas.loja) { await loja.create({ guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null}); datas.loja = await loja.findOne({ guildID: inter.guild.id }) }
        
                if (datas.user.termos == false) {
                    return inter.reply({
                        embeds: [
                            new Discord.EmbedBuilder()
                                .setTitle("Termos de Serviço")
                                .setDescription(`**Você deve aceitar os termos de ${inter.guild.name} **\n\n${datas.loja.termos || "1 - Siga as ToS do discord.\n2 - Tenha paciencia com seu produto\n3 - Não temos responsibilidade sobre problemas futuros."}`)
                                .setColor("#FFFFFF")

                        ], ephemeral: true, components: [
                            new Discord.ActionRowBuilder().addComponents(
                                new Discord.ButtonBuilder()
                                    .setLabel("Aceitar Termos")
                                    .setCustomId("AceitarTermos")
                                    .setStyle(Discord.ButtonStyle.Success)

                            )
                        ]
                    })
                } else {
                    if (datas.loja.loja == 'false') {
                        return inter.reply({
                            embeds: [
                                new Discord.EmbedBuilder()
                                    .setTitle("Sistema de Compras")
                                    .setDescription("**A loja se encontra offline.**\n\n```yaml\nVolte novamente mais tarde```")
                                    .setColor("#FFFFFF")

                            ], ephemeral: true, components: [
                                new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                        .setLabel("Offline")
                                        .setCustomId("safdfddff")
                                        .setDisabled(true)
                                        .setStyle(Discord.ButtonStyle.Secondary)

                                )
                            ]
                        })
                    } else {
                        if (datas.produto.estoque.length <= 0) { 
                            return inter.reply({
                                embeds: [
                                    new Discord.EmbedBuilder()
                                        .setTitle("Sistema de Compras")
                                        .setDescription("**Esse produto está sem estoque no momento.**\n\n```yaml\nVolte novamente mais tarde```")
                                        .setColor("#FFFFFF")
    
                                ], ephemeral: true, components: [
                                    new Discord.ActionRowBuilder().addComponents(
                                        new Discord.ButtonBuilder()
                                            .setLabel("Offline")
                                            .setCustomId("safdfddff")
                                            .setDisabled(true)
                                            .setStyle(Discord.ButtonStyle.Secondary)
    
                                    )
                                ]
                            })

                         }   else {
                        if (inter.guild.channels.cache.find(e => e.topic == inter.user.id)) {
                            let cana = inter.guild.channels.cache.find(e => e.topic == inter.user.id)
                            return inter.reply({
                                embeds: [
                                    new Discord.EmbedBuilder()
                                        .setTitle("Sistema de Compras")
                                        .setDescription("**Você já tem um ticket aberto!**\n\n```yaml\nClique no botão abaixo para ir para seu ticket.```")
                                        .setColor("#FFFFFF")

                                ], ephemeral: true, components: [
                                    new Discord.ActionRowBuilder().addComponents(
                                        new Discord.ButtonBuilder()
                                            .setLabel("Clique aqui para ir ao seu ticket")
                                            .setURL(cana.url)
                                            .setStyle(Discord.ButtonStyle.Link)

                                    )
                                ]
                            })

                        }
                        else {
                            const { ChannelType, PermissionsBitField } = require('discord.js');

                        let canal = await    inter.guild.channels.create({
                                name: `carrinho_${inter.user.username}`,
                                topic: inter.user.id,
                                parent: inter.channel.parentId,
                                type: ChannelType.GuildText,
                                permissionOverwrites: [
                                    {
                                        id: inter.guild.id,
                                        deny: [PermissionsBitField.Flags.ViewChannel],
                                    },
                                    {
                                        id: inter.user.id,
                                        allow: [PermissionsBitField.Flags.ViewChannel],
                                        deny: [PermissionsBitField.Flags.SendMessages],
                                    },

                                ],
                            })
                                inter.reply({
                                    embeds: [
                                        new Discord.EmbedBuilder()
                                            .setTitle("Sistema de Compras")
                                            .setDescription(`*Vá para seu ticket, ${canal}*`)
                                            .setColor("#FFFFFF")

                                    ], ephemeral: true, components: [
                                        new Discord.ActionRowBuilder().addComponents(
                                            new Discord.ButtonBuilder()
                                                .setLabel("Clique aqui para ir ao seu ticket")
                                                .setURL(canal.url)
                                                .setStyle(Discord.ButtonStyle.Link)

                                        )
                                    ]
                                })
                               let msgsg = await canal.send({
                                    embeds: [
                                        new Discord.EmbedBuilder()
                                            .setTitle("Sistema de Compras")
                                            .setDescription(`💻 Produto: ${datas.produto.nome}\n💎 Preço: R$${datas.produto.valor}\n🌄 Quantidade: 1`)
                                            .setColor("#FFFFFF")

                                    ], content:inter.user.toString(), ephemeral: true, components: [
                                        new Discord.ActionRowBuilder().addComponents(
                                            new Discord.ButtonBuilder()
                                                .setCustomId("Mais")
                                                .setEmoji("➕")
                                                .setStyle(Discord.ButtonStyle.Secondary),
                                                new Discord.ButtonBuilder()
                                                .setCustomId("Menos")
                                                .setEmoji("➖")
                                                .setStyle(Discord.ButtonStyle.Secondary),
                                                new Discord.ButtonBuilder()
                                                .setCustomId("pag1")
                                                .setEmoji("✅")
                                                .setStyle(Discord.ButtonStyle.Secondary),
                                                new Discord.ButtonBuilder()
                                                .setCustomId("cancel")
                                                .setEmoji("❌")
                                                .setStyle(Discord.ButtonStyle.Secondary),


                                        )
                                    ]
                              
                            })


                            await compras.create({channelId:canal.id,idCompra:msgsg.id,bodyCompra:null,user:inter.user.id,produto:datas.produto.nome,status:"pendente",valor:datas.produto.valor,quantidade:'1',valororiginal:datas.produto.valor,cupom:null})
                        }
                        }
                    }
                }
                break
            }
            case 'AceitarTermos': {
                
                await users.updateOne({ userID: inter.user.id }, { $set: { termos: true } })
                inter.update({
                    embeds: [
                        new Discord.EmbedBuilder()
                            .setTitle("Termos de Serviço")
                            .setDescription(`**Sucesso você aceitou os termos de ${inter.guild.name} **\n\nUse a interação novamente.`)
                            .setColor("#FFFFFF")

                    ], ephemeral: true, components: [
                        new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                                .setLabel("Aceitar Termos")
                                .setCustomId("AceitarTermos")
                                .setStyle(Discord.ButtonStyle.Success)
                                .setDisabled(true)

                        )
                    ]

                })
                break
            }
            case 'Mais' : {
                let datas = {
                    loja: await loja.findOne({ guildID: inter.guild.id }),
                    user: await users.findOne({ userID: inter.user.id }),
                    compra: await compras.findOne({ channelId: inter.channel.id })
                }
                if(datas.compra.user !== inter.user.id) return inter.deferUpdate()
                datas.produto = await produtos.findOne({ nome: datas.compra.produto })
                if (!datas.user) { await users.create({ userID: inter.user.id, valor: 0, produtos: 0, perm: false, termos: false }); datas.user = await users.findOne({ userID: inter.user.id }) }
                if (!datas.loja) { await loja.create({ guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null}); datas.loja = await loja.findOne({ guildID: inter.guild.id }) }
           
                if(Number(datas.produto.estoque.length) == Number(datas.compra.quantidade)  ) return inter.deferUpdate()
       
               let quant = Number(datas.compra.quantidade) + 1
               let valor = Number(datas.produto.valor) * quant
                await compras.updateOne({channelId:inter.channel.id}, {$set:{quantidade:quant,valor:valor,valororiginal:valor}})
               
                await inter.update({
                    embeds: [
                        new Discord.EmbedBuilder()
                            .setTitle("Sistema de Compras")
                            .setDescription(`💻 Produto: ${datas.produto.nome}\n💎 Preço: R$${valor}\n🌄 Quantidade: ${quant}`)
                            .setColor("#FFFFFF")

                    ], content:inter.user.toString(), ephemeral: true
              
            })
            break
            }
            case 'Menos' : {
                let datas = {
                    loja: await loja.findOne({ guildID: inter.guild.id }),
                    user: await users.findOne({ userID: inter.user.id }),
                    compra: await compras.findOne({ channelId: inter.channel.id })
                }
                if(datas.compra.user !== inter.user.id) return inter.deferUpdate()
                datas.produto = await produtos.findOne({ nome: datas.compra.produto })
                if (!datas.user) { await users.create({ userID: inter.user.id, valor: 0, produtos: 0, perm: false, termos: false }); datas.user = await users.findOne({ userID: inter.user.id }) }
                if (!datas.loja) { await loja.create({ guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null}); datas.loja = await loja.findOne({ guildID: inter.guild.id }) }
           
                if( Number(datas.compra.quantidade)  == 1) return inter.deferUpdate()
       
               let quant = Number(datas.compra.quantidade) - 1
               let valor = Number(datas.produto.valor) * quant
                await compras.updateOne({channelId:inter.channel.id}, {$set:{quantidade:quant,valor:valor,valororiginal:valor }})
               
                await inter.update({
                    embeds: [
                        new Discord.EmbedBuilder()
                            .setTitle("Sistema de Compras")
                            .setDescription(`💻 Produto: ${datas.produto.nome}\n💎 Preço: R$${valor}\n🌄 Quantidade: ${quant}`)
                            .setColor("#FFFFFF")

                    ], content:inter.user.toString(), ephemeral: true,
              
            })
            break
            }
            case 'pag1' : {
                let datas = {
                    loja: await loja.findOne({ guildID: inter.guild.id }),
                    user: await users.findOne({ userID: inter.user.id }),
                    compra: await compras.findOne({ channelId: inter.channel.id })
                }
         
                datas.produto = await produtos.findOne({ nome: datas.compra.produto })
                if (!datas.user) { await users.create({ userID: inter.user.id, valor: 0, produtos: 0, perm: false, termos: false }); datas.user = await users.findOne({ userID: inter.user.id }) }
                if (!datas.loja) { await loja.create({ guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null}); datas.loja = await loja.findOne({ guildID: inter.guild.id }) }
                await inter.update({
                    embeds: [
                        new Discord.EmbedBuilder()
                            .setTitle("Sistema de Compras")
                            .setDescription(`💻 Cupom: \`Nenhum\`\n\n💎 Valor com Cupom: R$${datas.produto.valor * datas.compra.quantidade}\n\n☀ Valor Sem Cupom: R$${datas.produto.valor * datas.compra.quantidade}`)
                            .setColor("#FFFFFF")

                    ], content:inter.user.toString(), ephemeral: true, components: [
                        new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId("addCupom")
                                .setLabel("Adicionar Cupom")
                                .setEmoji("✔")
                                .setStyle(Discord.ButtonStyle.Secondary),
                                new Discord.ButtonBuilder()
                                .setCustomId("pag2")
                                .setEmoji("✅")
                                .setStyle(Discord.ButtonStyle.Secondary),
                                new Discord.ButtonBuilder()
                                .setCustomId("cancel")
                                .setEmoji("❌")
                                .setStyle(Discord.ButtonStyle.Secondary),


                        )
                    ]
              
            })
            break
            }
            case 'addCupom' : {
                await inter.update({components: [
                    new Discord.ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder()
                            .setCustomId("addCupom")
                            .setLabel("Adicionar Cupom")
                            .setDisabled(true)
                            .setEmoji("✔")
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId("pag2")
                            .setEmoji("✅")
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId("cancel")
                            .setEmoji("❌")
                            .setStyle(Discord.ButtonStyle.Secondary),


                    )
                ]})
                const { ChannelType, PermissionsBitField } = require('discord.js');

                await    inter.channel.edit({
       
                    permissionOverwrites: [
                        {
                            id: inter.guild.id,
                            deny: [PermissionsBitField.Flags.ViewChannel],
                        },
                        {
                            id: inter.user.id,
                            allow: [PermissionsBitField.Flags.ViewChannel],
                            allow: [PermissionsBitField.Flags.SendMessages],
                        },

                    ],
                })
                let datas = {
                    loja: await loja.findOne({ guildID: inter.guild.id }),
                    user: await users.findOne({ userID: inter.user.id }),
                    compra: await compras.findOne({ channelId: inter.channel.id })
                }
        
                datas.produto = await produtos.findOne({ nome: datas.compra.produto })
                if (!datas.user) { await users.create({ userID: inter.user.id, valor: 0, produtos: 0, perm: false, termos: false }); datas.user = await users.findOne({ userID: inter.user.id }) }
                if (!datas.loja) { await loja.create({ guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null}); datas.loja = await loja.findOne({ guildID: inter.guild.id }) }
                await inter.editReply({
                    embeds: [
                        new Discord.EmbedBuilder()
                            .setTitle("Sistema de Compras")
                            .setDescription(`💻 Cupom: \`Nenhum\`\n\n💎 Valor com Cupom: R$${datas.produto.valor * datas.compra.quantidade}\n\n☀ Valor Sem Cupom: R$${datas.produto.valor * datas.compra.quantidade}`)
                            .setColor("#FFFFFF")

                    ], content:inter.user.toString(), ephemeral: true, components: [
                        new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId("addCupom")
                                .setLabel("Adicionar Cupom")
                                .setDisabled(true)
                                .setEmoji("✔")
                                .setStyle(Discord.ButtonStyle.Secondary),
                                new Discord.ButtonBuilder()
                                .setCustomId("pag2")
                                .setEmoji("✅")
                                .setStyle(Discord.ButtonStyle.Secondary),
                                new Discord.ButtonBuilder()
                                .setCustomId("cancel")
                                .setEmoji("❌")
                                .setStyle(Discord.ButtonStyle.Secondary),


                        )
                    ]
              
            })
            let çd = await inter.channel.send({content:"❓ Envie o cupom abaixo"})
            const filter = m => m.author.id == inter.user.id;
            const collector = çd.channel.createMessageCollector({ filter, time: 60000 });
            
            collector.on('collect', async m => {
                await    inter.channel.edit({
       
                    permissionOverwrites: [
                        {
                            id: inter.guild.id,
                            deny: [PermissionsBitField.Flags.ViewChannel],
                        },
                        {
                            id: inter.user.id,
                            allow: [PermissionsBitField.Flags.ViewChannel],
                            deny: [PermissionsBitField.Flags.SendMessages],
                        },

                    ],
                })
                let cupo = m.content
                let cupomdb = await cupom.findOne({nome:cupo})
                m.delete()
                collector.stop()
                if(!cupomdb) {
                   
                    await inter.editReply({
                        embeds: [
                            new Discord.EmbedBuilder()
                                .setTitle("Sistema de Compras")
                                .setDescription(`💻 Cupom: \`Nenhum\`\n\n💎 Valor com Cupom: R$${datas.produto.valor * datas.compra.quantidade}\n\n☀ Valor Sem Cupom: R$${datas.produto.valor * datas.compra.quantidade}`)
                                .setColor("#FFFFFF")
    
                        ], content:inter.user.toString(), ephemeral: true, components: [
                            new Discord.ActionRowBuilder().addComponents(
                                new Discord.ButtonBuilder()
                                    .setCustomId("addCupom")
                                    .setLabel("Adicionar Cupom")
                                    .setDisabled(false)
                                    .setEmoji("✔")
                                    .setStyle(Discord.ButtonStyle.Secondary),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("pag2")
                                    .setEmoji("✅")
                                    .setStyle(Discord.ButtonStyle.Secondary),
                                    new Discord.ButtonBuilder()
                                    .setCustomId("cancel")
                                    .setEmoji("❌")
                                    .setStyle(Discord.ButtonStyle.Secondary),
    
    
                            )
                        ]
                  
                })
                
                return çd.channel.send({content:"❌ Cupom Invalido"}).then(m=>{setTimeout(()=>{m.delete()},4000)})
                } else { 
            
                    if(cupomdb.produto !== null && cupomdb.produto == datas.produto.nome) {
                        if(cupomdb.valormin > Number(datas.compra.valor)) {
                            await inter.editReply({
                                embeds: [
                                    new Discord.EmbedBuilder()
                                        .setTitle("Sistema de Compras")
                                        .setDescription(`💻 Cupom: \`Nenhum\`\n\n💎 Valor com Cupom: R$${datas.produto.valor * datas.compra.quantidade}\n\n☀ Valor Sem Cupom: R$${datas.produto.valor * datas.compra.quantidade}`)
                                        .setColor("#FFFFFF")
            
                                ], content:inter.user.toString(), ephemeral: true, components: [
                                    new Discord.ActionRowBuilder().addComponents(
                                        new Discord.ButtonBuilder()
                                            .setCustomId("addCupom")
                                            .setLabel("Adicionar Cupom")
                                            .setDisabled(false)
                                            .setEmoji("✔")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                            new Discord.ButtonBuilder()
                                            .setCustomId("pag2")
                                            .setEmoji("✅")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                            new Discord.ButtonBuilder()
                                            .setCustomId("cancel")
                                            .setEmoji("❌")
                                            .setStyle(Discord.ButtonStyle.Secondary),
            
            
                                    )
                                ]
                          
                        })
                        
                        return çd.channel.send({content:"❌ Cupom tem o valor minimo de R$"+cupomdb.valormin}).then(m=>{setTimeout(()=>{m.delete()},4000)})
    
                        }
                            let valor =Number(datas.compra.valor) - (Math.floor(Number(datas.compra.valor) * (cupomdb.porcentagem / 100)) )
                            if(valor.toString().includes(".") && valor.toString().split(".")[1].length > 2 ) valor = datas.compra.valor
                            if(valor.toString().includes("-")) valor = datas.compra.valor
                            await inter.editReply({
                            embeds: [
                                new Discord.EmbedBuilder()
                                    .setTitle("Sistema de Compras")
                                    .setDescription(`💻 Cupom: \`${cupomdb.nome}\`\n\n💎 Valor com Cupom: R$${valor}\n\n☀ Valor Sem Cupom: R$${datas.compra.valor}`)
                                    .setColor("#FFFFFF")
        
                            ],
                        })
                        await compras.updateOne({channelId:inter.channel.id},{ $set:{valor:valor,cupom:cupomdb.nome}})
                        await cupom.updateOne({nome:cupomdb.nome},{$set:{quantidade:Number(cupomdb.quantidade) - 1}})
                        
                    } else if(cupomdb.produto == null ) {
                        if(cupomdb.valormin > Number(datas.compra.valor)) {
                            await inter.editReply({
                                embeds: [
                                    new Discord.EmbedBuilder()
                                        .setTitle("Sistema de Compras")
                                        .setDescription(`💻 Cupom: \`Nenhum\`\n\n💎 Valor com Cupom: R$${datas.produto.valor * datas.compra.quantidade}\n\n☀ Valor Sem Cupom: R$${datas.produto.valor * datas.compra.quantidade}`)
                                        .setColor("#FFFFFF")
            
                                ], content:inter.user.toString(), ephemeral: true, components: [
                                    new Discord.ActionRowBuilder().addComponents(
                                        new Discord.ButtonBuilder()
                                            .setCustomId("addCupom")
                                            .setLabel("Adicionar Cupom")
                                            .setDisabled(false)
                                            .setEmoji("✔")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                            new Discord.ButtonBuilder()
                                            .setCustomId("pag2")
                                            .setEmoji("✅")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                            new Discord.ButtonBuilder()
                                            .setCustomId("cancel")
                                            .setEmoji("❌")
                                            .setStyle(Discord.ButtonStyle.Secondary),
            
            
                                    )
                                ]
                          
                        })
                        
                        return çd.channel.send({content:"❌ Cupom tem o valor minimo de R$"+cupomdb.valormin}).then(m=>{setTimeout(()=>{m.delete()},4000)})
    
                        }
                        let valor =Number(datas.compra.valor) - (Math.floor(Number(datas.compra.valor) * (cupomdb.porcentagem / 100)) )
                        if(valor.toString().includes(".") && valor.toString().split(".")[1].length > 2 ) valor = datas.compra.valor
if(valor.toString().includes("-")) valor = datas.compra.valor
                        await inter.editReply({
                            embeds: [
                                new Discord.EmbedBuilder()
                                    .setTitle("Sistema de Compras")
                                    .setDescription(`💻 Cupom: \`${cupomdb.nome}\`\n\n💎 Valor com Cupom: R$${valor}\n\n☀ Valor Sem Cupom: R$${datas.compra.valor}`)
                                    .setColor("#FFFFFF")
        
                            ],
                        })
                        await compras.updateOne({channelId:inter.channel.id},{ $set:{valor:valor,cupom:cupomdb.nome}})
                        await cupom.updateOne({nome:cupomdb.nome},{$set:{quantidade:cupomdb.quantidade - 1}})
                        
                    } else if(cupomdb.produto !== null && cupomdb.produto !== datas.produto.nome) {
                        await inter.editReply({
                            embeds: [
                                new Discord.EmbedBuilder()
                                    .setTitle("Sistema de Compras")
                                    .setDescription(`💻 Cupom: \`Nenhum\`\n\n💎 Valor com Cupom: R$${datas.produto.valor * datas.compra.quantidade}\n\n☀ Valor Sem Cupom: R$${datas.produto.valor * datas.compra.quantidade}`)
                                    .setColor("#FFFFFF")
        
                            ], content:inter.user.toString(), ephemeral: true, components: [
                                new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                        .setCustomId("addCupom")
                                        .setLabel("Adicionar Cupom")
                                        .setDisabled(false)
                                        .setEmoji("✔")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                        .setCustomId("pag2")
                                        .setEmoji("✅")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                        .setCustomId("cancel")
                                        .setEmoji("❌")
                                        .setStyle(Discord.ButtonStyle.Secondary),
        
        
                                )
                            ]
                      
                    })
                    
                    return çd.channel.send({content:"❌ Cupom não pode ser usado nesse produto"}).then(m=>{setTimeout(()=>{m.delete()},4000)})

                        
                    } else if(cupomdb.valormin > Number(datas.compra.valor)) {
                        await inter.editReply({
                            embeds: [
                                new Discord.EmbedBuilder()
                                    .setTitle("Sistema de Compras")
                                    .setDescription(`💻 Cupom: \`Nenhum\`\n\n💎 Valor com Cupom: R$${datas.produto.valor * datas.compra.quantidade}\n\n☀ Valor Sem Cupom: R$${datas.produto.valor * datas.compra.quantidade}`)
                                    .setColor("#FFFFFF")
        
                            ], content:inter.user.toString(), ephemeral: true, components: [
                                new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                        .setCustomId("addCupom")
                                        .setLabel("Adicionar Cupom")
                                        .setDisabled(false)
                                        .setEmoji("✔")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                        .setCustomId("pag2")
                                        .setEmoji("✅")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                        .setCustomId("cancel")
                                        .setEmoji("❌")
                                        .setStyle(Discord.ButtonStyle.Secondary),
        
        
                                )
                            ]
                      
                    })
                    
                    return çd.channel.send({content:"❌ Cupom tem o valor minimo de R$"+cupomdb.valormin}).then(m=>{setTimeout(()=>{m.delete()},4000)})

                    } else if(cupomdb.quantidade <= 0) {
                        await inter.editReply({
                            embeds: [
                                new Discord.EmbedBuilder()
                                    .setTitle("Sistema de Compras")
                                    .setDescription(`💻 Cupom: \`Nenhum\`\n\n💎 Valor com Cupom: R$${datas.produto.valor * datas.compra.quantidade}\n\n☀ Valor Sem Cupom: R$${datas.produto.valor * datas.compra.quantidade}`)
                                    .setColor("#FFFFFF")
        
                            ], content:inter.user.toString(), ephemeral: true, components: [
                                new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                        .setCustomId("addCupom")
                                        .setLabel("Adicionar Cupom")
                                        .setDisabled(false)
                                        .setEmoji("✔")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                        .setCustomId("pag2")
                                        .setEmoji("✅")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                        .setCustomId("cancel")
                                        .setEmoji("❌")
                                        .setStyle(Discord.ButtonStyle.Secondary),
        
        
                                )
                            ]
                      
                    })
                    
                    return çd.channel.send({content:"❌ Esse cupom não pode ser mais usado"}).then(m=>{setTimeout(()=>{m.delete()},4000)})

                    } else {
                        let valor =Number(datas.compra.valor) - (Math.floor(Number(datas.compra.valor) * (cupomdb.porcentagem / 100)) )
                        if(valor.toString().includes(".") && valor.toString().split(".")[1].length > 2 ) valor = datas.compra.valor
                        if(valor.toString().includes("-")) valor = datas.compra.valor
                        await inter.editReply({
                            embeds: [
                                new Discord.EmbedBuilder()
                                    .setTitle("Sistema de Compras")
                                    .setDescription(`💻 Cupom: \`${cupomdb.nome}\`\n\n💎 Valor com Cupom: R$${valor}\n\n☀ Valor Sem Cupom: R$${datas.compra.valor}`)
                                    .setColor("#FFFFFF")
        
                            ],
                        })
                        await compras.updateOne({channelId:inter.channel.id},{ $set:{valor:valor,cupom:cupomdb.nome}})
                        await cupom.updateOne({nome:cupomdb.nome},{$set:{quantidade:cupomdb.quantidade - 1}})
                    }
                }
            });
            collector.on('end', collected => {
                çd.delete()
            });
            break
        }
        case 'cancel' : {
            await compras.deleteOne({channelId:inter.channel.id})
        inter.channel.delete()
            break
        }
        case 'pag2' : {
            let datas = {
                loja: await loja.findOne({ guildID: inter.guild.id }),
                user: await users.findOne({ userID: inter.user.id }),
                compra: await compras.findOne({ channelId: inter.channel.id })
            }
     
            datas.produto = await produtos.findOne({ nome: datas.compra.produto })
            if (!datas.user) { await users.create({ userID: inter.user.id, valor: 0, produtos: 0, perm: false, termos: false }); datas.user = await users.findOne({ userID: inter.user.id }) }
            if (!datas.loja) { await loja.create({ guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null}); datas.loja = await loja.findOne({ guildID: inter.guild.id }) }
            
            mercadopago.configurations.setAccessToken(datas.loja.acesstoken);
            var payment_data = {
                transaction_amount: Number(datas.compra.valor), 
                description: `Pagamento - ${inter.user.username}`,
                payment_method_id: 'pix',
                payer: {
                    email: `${inter.user.id}@gmail.com`,
                    first_name: `Kauã Felipe`,
                    last_name: `Vinhando Aguiari`,
                    identification: {
                        type: 'CPF',
                        number: '11547089938'
                    },
    
                    address: {
                        zip_code: '86078680',
                        street_name: 'Rua Domingos Julião',
                        street_number: '164',
                        neighborhood: 'Jardim Roma',
                        city: 'Londrina',
                        federal_unit: 'PR'
                    }
                }
            }
            mercadopago.payment.create(payment_data)
            .then(async function(data) {
    
                await compras.updateOne({channelId:inter.channel.id},{$set:{bodyCompra:data.body.id}})
    
                const buffer = Buffer.from(data.body.point_of_interaction.transaction_data.qr_code_base64, "base64");
                const attachment = new Discord.AttachmentBuilder(buffer, "payment.png");
                await inter.update({
                    embeds: [
                        new Discord.EmbedBuilder()
                            .setTitle("Sistema de Compras")
                            .setDescription(`> Pague seu produto via PIX escaneando o qr abaixo ou copiando a chave aleatoria`)
                            .setColor("#FFFFFF")
    
                    ], content:inter.user.toString(),files:[attachment] ,ephemeral: true, components: [
                        new Discord.ActionRowBuilder().addComponents(
   

                                new Discord.ButtonBuilder()
                                .setCustomId("cancel")
                                .setEmoji("❌")
                                .setStyle(Discord.ButtonStyle.Secondary),
    
    
                        )
                    ]
              
            })
            
            inter.message.reply({content:`${data.body.point_of_interaction.transaction_data.qr_code}`})
          
            })    

        break
        }
        case 'close_2' : {
        inter.channel.delete()
            break
        }
        }
    }
})
