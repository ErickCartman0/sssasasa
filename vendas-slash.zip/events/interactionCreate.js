const Client = require("../index").Client
const { InteractionType } = require('discord.js')
const Discord = require('discord.js')
const User = require("../models/User")
const config = require("../config.json")

Client.on('interactionCreate', async inter => {

    if(inter.type === InteractionType.ApplicationCommand) {

        let slashCmds = Client.SlashCmds.get(inter.commandName)

        if(!slashCmds.Permissions) slashCmds.Permissions = []
        if(!inter.member.permissions.has(slashCmds.Permissions)) {

        let p = new Discord.PermissionsBitField(slashCmds.Permissions).toArray().join(', ')

       return inter.reply({content: `Você não tem as permissões necessárias para usar este comando. \n > ${p} `, ephemeral: true})
    }
    let database = await User.findOne({ userID: inter.user.id })
    if(inter.user.id==config.ownerid) {
        if(slashCmds) slashCmds.run(Client, inter)
    } else if (!database) {
        return inter.reply({content: `Você não tem perm para usar meus comandos`, ephemeral: true})
    } else if (database.perm == false) {
        return inter.reply({content: `Você não tem perm para usar meus comandos`, ephemeral: true})
    } else if (database.perm == true) {
        if(slashCmds) slashCmds.run(Client, inter)
    } 
        
       
    }
})
