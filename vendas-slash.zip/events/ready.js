const Client = require('../index').Client
const Discord = require('discord.js')
const config = require('../config.json')
const mongo = require("mongoose");
const produtos = require("../models/produtos")
Client.on('ready', async(client) => {


    console.log(`${Client.user.tag} online!`)
    
  let data = Client.SlashCmds

  let filt1 = data.filter(c => c.Globally == true)
           
  await Client.application?.commands.set(filt1)
           
  let filt2 = data.filter(c => c.Globally == false)
            
  await Client.guilds.cache.get(config.testGuildId).commands.set(filt2)            

  mongo.connection.on('connected', () =>{
    console.log('🍃 MongoDB on')
  })
    client.MongoConnect()

})

