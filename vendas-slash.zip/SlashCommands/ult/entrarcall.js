const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const produtos = require("../../models/produtos")
const { ComponentType } = require('discord.js');
const voice = require("@discordjs/voice")
module.exports = {
    name: 'conectar',
    description: 'Conectar Call',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [
        {
            name: 'channel',
            description: 'Qual user deseja enviar',
            type: Discord.ApplicationCommandOptionType.Channel,
            required: true,
            channelTypes: [Discord.ChannelType.GuildVoice]
        },


    ],




    run: async (Client, inter) => {

        let channel = inter.options.getChannel("channel")
        let connection = voice.joinVoiceChannel({
            channelId: channel.id,
            guildId: inter.guild.id,
            adapterCreator: inter.guild.voiceAdapterCreator
        });
        inter.reply("Entrei com sucesso no canal de voz!")
    }
}