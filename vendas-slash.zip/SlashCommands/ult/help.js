const Discord = require('discord.js')
const ms = require("ms")
const {icon} = require("../../config.json")
const { QuickDB } = require("quick.db");
const db = new QuickDB();
module.exports = {
    name: 'help',
    description: 'Todos os meus comandos',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores


       


    run: async (Client, inter) => {


        const {readdirSync} = require("fs");

        let categorias = [];
        
        
        
        
        
        
        readdirSync("./SlashCommands/").forEach((dir) => {
        
        
          let data = new Object();
        
          data = {
            label: `${dir.charAt(0).toUpperCase() + dir.slice(1)}`,
            value: dir
          };
        
          categorias.push(data);
        });
        
        
        inter.reply({embeds:[
            new Discord.EmbedBuilder()
            .setColor("#ffffff")
            .setDescription(`Olá, ${inter.user.username}.\n> **Abaixo está minha lista de comandos**`)
                                ], components:[
                        new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.SelectMenuBuilder()
                            .setCustomId("help")
                            .setPlaceholder("Selecione um tipo de comando")
                            .addOptions(categorias)
                        )
                    ]}).then(message=>{
        
                    const { ComponentType } = require('discord.js');
        
                    const collector = message.createMessageComponentCollector({ componentType: ComponentType.SelectMenu, time: 60000*4 });
                    
                    collector.on('collect', i => {
                        if (i.user.id === inter.user.id) {
          if(i.customId == "help") {
            const commands = readdirSync(`./SlashCommands/${i.values[0]}/`).filter((file) =>
            file.endsWith(".js")
          );
            const cmds = commands.map((command) => {
        let file = require(`../../SlashCommands/${i.values[0]}/${command}`);
        
        if (!file.name) return "Sem nome definido.";
        
        let name = file.name.replace(".js", "");
        let description = file.description;
        let options = ''
        if(file.options !== undefined) {
            file.options.map(value=>{
                if(value.type == 1) options+=`\n- ${value.name}`
            })
        }
        
        return `[${name}] : ${description}${options} \n`;
        }).join("")
            i.update({embeds:[
                new Discord.EmbedBuilder()
                .setColor("#ffffff")
                .setTitle(`${i.values[0].charAt(0).toUpperCase() + i.values[0].slice(1)}`)
                .setDescription(`Olá, ${inter.user.username}.\n> **Abaixo está minha lista de comandos**\n💻 Categoria Selecionada \`${i.values[0].charAt(0).toUpperCase() + i.values[0].slice(1)}\`\n\`\`\`[Comandos]\n${cmds}\`\`\``)
     
                        ], components:[
                            new Discord.ActionRowBuilder()
                            .addComponents(
                                new Discord.SelectMenuBuilder()
                                .setCustomId("help")
                                .setPlaceholder("Selecione um tipo de comando")
                                .addOptions(categorias)
                            )
                        ]})
          }
                        } else {
                            i.reply({ content: `Você não é ${inter.user} para poder usar isso!`, ephemeral: true });
                        }
                    });
                })
    }
}