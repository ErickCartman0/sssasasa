const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const produtos = require("../../models/produtos")
const { ComponentType } = require('discord.js');
module.exports = {
    name: 'dm',
    description: 'Envia msg dm',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [
        {
            name: 'user',
            description: 'Qual user deseja enviar',
            type: Discord.ApplicationCommandOptionType.User,
            required: true
        },
        {
            name: 'msg',
            description: 'Qual a msg que deseja enviar?',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },

    ],




    run: async (Client, inter) => {

        let user = inter.options.getUser("user")
        let msg = inter.options.getString("msg")


        user.send({content:msg}).then(()=>{
            inter.reply("Mensagem Enviada!")
        }).catch(err=>{
            inter.reply("Erro ao enviar mensagem")
        })

    }
}