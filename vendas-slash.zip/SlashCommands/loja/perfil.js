const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const use = require("../../models/User")
const { ComponentType } = require('discord.js');
module.exports = {
    name: 'perfil',
    description: 'Veja o perfil de um user',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'user',
            description: 'Usuario que deseja ver o perfil',
            type: Discord.ApplicationCommandOptionType.User,
            required: false
        },

    ],




    run: async (Client, inter) => {
        let user = inter.options.getUser("user") || inter.user
        let database = await use.findOne({ userID: user.id })
        if (!database) {
            return inter.reply({ embeds: [new Discord.EmbedBuilder().setColor("#fff").addFields(
                {name:`User`,value:`${user.username}(${user.id})`},
                {name:`Valor Gasto:`,value:` \`R$00\``},
                {name:`Produtos Comprados`,value:` \`0\` produtos`},
                
            
            ).setAuthor({ name: user.username, iconURL: user.avatarURL() })] })
        } else {

            return inter.reply({ embeds: [new Discord.EmbedBuilder().setColor("#fff").addFields(
                {name:`User`,value:`${user.username}(${user.id})`},
                {name:`Valor Gasto:`,value:` \`R$${database.valor || "00"}\``},
                {name:`Produtos Comprados`,value:` \`${database.produtos||'0'}\` produtos`},
                
            
            ).setAuthor({ name: user.username, iconURL: user.avatarURL() })] })
        
        }

    }
}