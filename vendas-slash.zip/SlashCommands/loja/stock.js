const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const produtos = require("../../models/produtos")
const { ComponentType } = require('discord.js');
module.exports = {
    name: 'stock',
    description: 'Veja o stock de um produto',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'name',
            description: 'Qual o nome do produto que deseja ver o stock ',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },

    ],




    run: async (Client, inter) => {

        let database = await produtos.findOne({ nome: inter.options.getString("name") })
        if (!database) {
            return inter.reply({ embeds: [new Discord.EmbedBuilder().setColor("#fff").setDescription("Produto não encontrado!").setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })] })
        } else {

            let valores = database.estoque
            let estoque = valores.map(valor => `-  ${valor}`).join("\n")
            if (valores.length < 1) estoque = 'Não há estoque'
            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`💎 Nome: ${database.nome}\n🛒 Quantidade de intens: ${valores.length}\n\`\`\`${estoque}\`\`\``)
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
     

            inter.reply({ embeds: [embed] })
        
        }

    }
}