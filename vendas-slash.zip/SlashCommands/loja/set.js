const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const produtos = require("../../models/produtos")
const lm = require("../../models/msgs")
module.exports = {
    name: 'set',
    description: 'Enviar mensagem de vendas',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'name',
            description: 'Qual o nome do produto que deseja enviar ',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },

],

       


    run: async (Client, inter) => {
      
        let database = await produtos.findOne({nome:inter.options.getString("name")})
        if(!database) {
            return inter.reply({embeds:[new Discord.EmbedBuilder().setColor("#fff").setDescription("Produto não encontrado!").setAuthor({name:inter.user.username,iconURL:inter.user.avatarURL()})]})
        } else {
     
            let embed = new Discord.EmbedBuilder()
            .setAuthor({name:inter.guild.name, iconURL:inter.guild.iconURL()})
            .setDescription(`\`\`\`${database.desc}\`\`\`\n**💻 - Nome: ${database.nome}**\n**💎 - Preço: R$${database.valor}**\n**📦 - Estoque: ${database.estoque.length}**`)
            .setImage(database.banner)
            .setColor("#fff")
            .setFooter({text:`Utima atualização`})
            .setTimestamp()

            let row = new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                .setCustomId("Comprar")
                .setLabel("Comprar")
                .setStyle(Discord.ButtonStyle.Primary)
            )
            inter.reply("Upload...").then( async()=>{
                inter.deleteReply()
              let msg = await  inter.channel.send({embeds:[embed],components:[row]})
              await produtos.updateOne({nome:`${database.nome}`},{$push:{msgs:`${inter.channel.id}_${msg.id}`}})
              await lm.create({msgId:msg.id,nome:database.nome})
            })
        }

    }
}