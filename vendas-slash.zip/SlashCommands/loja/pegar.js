const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const compra = require("../../models/compras")
const { ComponentType } = require('discord.js');
const compras = require('../../models/compras');
module.exports = {
    name: 'pegar',
    description: 'Pegar Produtos de uma compra',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'id',
            description: 'Qual o id do produto',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },

    ],




    run: async (Client, inter) => {

        let database = await compras.findOne({ bodyCompra: inter.options.getString("id") })
        if (!database) {
            return inter.reply({ embeds: [new Discord.EmbedBuilder().setColor("#fff").setDescription("Compra não encontrada!").setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })] })
        } else {


            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`💎 Produto: ${database.produto}\n👦 User: <@${database.user}> (${database.user})\n🛒 Quantidade: ${database.quantidade}\n\n\`\`\`${database.produtos}\`\`\``)
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
     

            inter.reply({ embeds: [embed] })
        
        }

    }
}