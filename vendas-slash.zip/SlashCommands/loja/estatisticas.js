const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const compra = require("../../models/compras")
const { ComponentType } = require('discord.js');
const compras = require('../../models/vendas');
module.exports = {
    name: 'estatisticas',
    description: 'Estatisticas de vendas',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores





    run: async (Client, inter) => {

        let database = await compras.find()
        if (!database) {
            return inter.reply({ embeds: [new Discord.EmbedBuilder().setColor("#fff").setDescription("Nenhuma compra encontrada").setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })] })
        } else {
            async function atSemana ()
            {
                let atualDay = new Date().getDay()
                let atData = new Date()
                let atFullDate = atData.toLocaleDateString()
                atFullDate = atFullDate.split("/")
                if(atualDay < 7) atualDay = (7 - atualDay) + atualDay
                let fullValor = 0
                let fullProdutos = 0
                for(let i = 0; i< atualDay;i++) {
                  let values =   await compras.findOne({data:`${atFullDate[0] - i}/${atFullDate[1]}/${atFullDate[2]}`})
                if(!values) {

                } else {
                    fullValor+= values.valor
                    fullProdutos+= values.produtos
                }
                
                }
                return {fullProdutos,fullValor}
            }
            async function atTotal ()
            {
      
                let fullValor = 0
                let fullProdutos = 0
                database.forEach(value=>{
                    fullValor+=Number(value.valor)
                    fullProdutos+=Number(value.produtos)
                })
                return {fullProdutos,fullValor}
            }
            async function atDia ()
            {
      
                let fullValor = 0
                let fullProdutos = 0
                let valor = await compras.findOne({data:new Date().toLocaleDateString()})
                if(!valor) {} else {
                    fullValor += valor.valor
                    fullProdutos += valor.produtos
                }
                return {fullProdutos,fullValor}
            }
            let dia = await atDia()
            let semana = await atSemana()
            let total = await atTotal()
            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`Status de vendas`)
                .addFields(
                    {
                        name:`Venda Total`,
                        value:"Vendas total",
                        inline:true
                    },
                    {
                        name:`Valor Vendido`,
                        value: `R$${total.fullValor}`,
                        inline:true
                    },
                    {
                        name:`Produtos Vendidos`,
                        value: `${total.fullProdutos} produtos`,
                        inline:true
                    },
                    {
                        name:`Venda Semanal`,
                        value:"Vendas total na semana",
                        inline:true
                    },
                    {
                        name:`Valor Vendido`,
                        value: `R$${semana.fullValor}`,
                        inline:true
                    },
                    {
                        name:`Produtos Vendidos`,
                        value: `${semana.fullProdutos} produtos`,
                        inline:true
                    },
                    {
                        name:`Venda De hoje (${new Date().toLocaleDateString()})`,
                        value:`Vendas total de ${new Date().toLocaleDateString()}`,
                        inline:true
                    },
                    {
                        name:`Valor Vendido`,
                        value: `R$${dia.fullValor}`,
                        inline:true
                    },
                    {
                        name:`Produtos Vendidos`,
                        value: `${dia.fullProdutos} produtos`,
                        inline:true
                    },
                )
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
     

            inter.reply({ embeds: [embed] })
        
        }

    }
}