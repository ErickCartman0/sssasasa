const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const produtos = require("../../models/produtos")
const { ComponentType } = require('discord.js');
module.exports = {
    name: 'produtos',
    description: 'Lista de produtos',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
 




    run: async (Client, inter) => {

        let database = await produtos.find()
        let produt = await database.map(val=>`💎 Produto -  \`${val.nome}\`\n> Valor R$${val.valor}`).join("\n") || "Não há produtos"

            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`${produt}`)
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
     

            inter.reply({ embeds: [embed] })
        
       

    }
}