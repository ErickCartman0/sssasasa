const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const cup = require("../../models/cupom")
module.exports = {
    name: 'criarcupom',
    description: 'Sistema de criação de cupom',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'nome',
            description: 'Nome do cupom',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: 'quantidade',
            description: 'Quantidade do cupom',
            type: Discord.ApplicationCommandOptionType.Number,
            required: true
        },
        {
            name: 'porcentagem',
            description: 'Insira a porcentagem',
            type: Discord.ApplicationCommandOptionType.Number,
            required: true
        },
        {
            name: 'produto',
            description: 'Coloque o nome do produto que deseja setar o cupom, caso queria que seja para todos digite ALLCUPOM',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },
        {
            name: 'valormin',
            description: 'Coloque o valor minimo. 0 caso for sem valor',
            type: Discord.ApplicationCommandOptionType.Number,
            required: true
        },

    ],

       


    run: async (Client, inter) => {
let nome = inter.options.getString("nome")
let quantidade = inter.options.getNumber("quantidade")
let porcentagem = inter.options.getNumber("porcentagem")
let produto = inter.options.getString("produto")
let valormin = inter.options.getNumber("valormin")


let database = await cup.findOne({nome})
if(!database) {
    if(produto.includes('ALLCUPOM')) produto = null
await cup.create({
    nome,
    quantidade,
    porcentagem,
    produto,
    valormin

})
inter.reply(`Cupom **${nome}** foi registrado com a porcentagem \`${porcentagem}%\`!`)
} else {
    inter.reply("Ja existe um cupom com esse nome.")
}

    }
}