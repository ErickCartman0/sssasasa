const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const produtos = require("../../models/produtos")
const { ComponentType } = require('discord.js');
const { database } = require('firebase-admin');
module.exports = {
    name: 'config',
    description: 'Sistema de configurar produtos',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'name',
            description: 'Qual o nome do produto que deseja configurar ',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },

    ],




    run: async (Client, inter) => {

        let database = await produtos.findOne({ nome: inter.options.getString("name") })
        if (!database) {
            return inter.reply({ embeds: [new Discord.EmbedBuilder().setColor("#fff").setDescription("Produto não encontrado!").setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })] })
        } else {

            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`\`\`\`${database.desc}\`\`\`\n**💻 - Nome: ${database.nome}**\n**💎 - Preço: R$${database.valor}**\n**📦 - Estoque: ${database.estoque.length}**`)
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
                 let row  =  new Discord.ActionRowBuilder().addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('nome')
                        .setLabel("Nome")
                        .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                        .setCustomId('price')
                        .setLabel("Preço")
                        .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                        .setCustomId('desc')
                        .setLabel("Descrição")
                        .setStyle(Discord.ButtonStyle.Secondary),
                        new Discord.ButtonBuilder()
                        .setCustomId('banner')
                        .setLabel("Banner")
                        .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                        .setCustomId('estoque')
                        .setLabel("Estoque")
                        .setStyle(Discord.ButtonStyle.Secondary),
    
                )

        
            await inter.reply({ embeds: [embed], components: [row,      new Discord.ActionRowBuilder().addComponents(
                new Discord.ButtonBuilder()
                .setCustomId('attmsg')
                .setLabel("Atualizar Mensagem")
                .setStyle(Discord.ButtonStyle.Primary),

            )] }).then(msg => {



                const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 * 4 });

                collector.on('collect', async i => {
                    if (i.user.id === inter.user.id) {
                        if (i.customId == "attmsg") {
                 
                             database = await produtos.findOne({nome:database.nome})
            
          
                                let embed = new Discord.EmbedBuilder()
                                .setAuthor({name:inter.guild.name, iconURL:inter.guild.iconURL()})
                                .setDescription(`\`\`\`${database.desc}\`\`\`\n**💻 - Nome: ${database.nome}**\n**💎 - Preço: R$${database.valor}**\n**📦 - Estoque: ${database.estoque.length}**`)
                                .setImage(database.banner)
                                .setColor("#fff")
                                .setFooter({text:`Utima atualização`})
                                .setTimestamp()
                    
                                let row = new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                    .setCustomId("Comprar")
                                    .setLabel("Comprar")
                                    .setStyle(Discord.ButtonStyle.Primary)
                                )

                      i.deferUpdate()
                                
                         let msgs = await    database.msgs
                        msgs.forEach(async val=>{
                            await Client.channels.cache.get(val.split("_")[0]).messages.fetch(val.split("_")[1]).then(msg=>{
                                msg.edit({embeds:[embed],components:[row]})
                            }).catch(err=>{return})
                        })
                        } else if (i.customId == "nome") {
                            i.update({ content: "Envie o nome que deseja setar", embeds: [], components: [] })
                            const collector = inter.channel.createMessageCollector({ time: 60000 * 4 });

                            collector.on('collect', async m => {
                                let newName = m.content
                                collector.stop()
                                m.delete()
                                if (newName.length > 50) return i.editReply({ content: "Nome não pode passar de 50 caracteres" })
                                await produtos.updateOne({ nome: database.nome }, {
                                    $set: {
                                        nome: newName
                                    }
                                })

                                database = await produtos.findOne({ nome: newName })
                                let embed = new Discord.EmbedBuilder()
                                    .setColor("#fff")
                                    .setDescription(`\`\`\`${database.desc}\`\`\`\n**💻 - Nome: ${database.nome}**\n**💎 - Preço: R$${database.valor}**\n**📦 - Estoque: ${database.estoque.length}**`)
                                    .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
             

                                await i.editReply({ embeds: [embed], components: [row,      new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                    .setCustomId('attmsg')
                                    .setLabel("Atualizar Mensagem")
                                    .setStyle(Discord.ButtonStyle.Primary),
                    
                                )], content: "" })

                            });

                        } else       if (i.customId == "banner") {
                            i.update({ content: "Envie o banner que deseja setar", embeds: [], components: [] })
                            const collector = inter.channel.createMessageCollector({ time: 60000 * 4 });

                            collector.on('collect', async m => {
                                let newBanner = m.content
                                collector.stop()
                                m.delete()
                              
                                await produtos.updateOne({ nome: database.nome }, {
                                    $set: {
                                        banner: newBanner
                                    }
                                })

                                database = await produtos.findOne({ nome: database.nome })
                                let embed = new Discord.EmbedBuilder()
                                    .setColor("#fff")
                                    .setDescription(`\`\`\`${database.desc}\`\`\`\n**💻 - Nome: ${database.nome}**\n**💎 - Preço: R$${database.valor}**\n**📦 - Estoque: ${database.estoque.length}**`)
                                    .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
                
                                await i.editReply({ embeds: [embed], components: [row,      new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                    .setCustomId('attmsg')
                                    .setLabel("Atualizar Mensagem")
                                    .setStyle(Discord.ButtonStyle.Primary),
                    
                                )], content: "" })

                            });

                        } else if (i.customId == "desc") {
                            i.update({ content: "Envie a desc que deseja setar", embeds: [], components: [] })
                            const collector = inter.channel.createMessageCollector({ time: 60000 * 4 });

                            collector.on('collect', async m => {
                                let newDesc = m.content
                                collector.stop()
                                m.delete()
                                if (newDesc.length > 500) return i.editReply({ content: "A desc não pode passar de 500 caracteres" })
                                await produtos.updateOne({ nome: database.nome }, {
                                    $set: {
                                        desc: newDesc
                                    }
                                })

                                database = await produtos.findOne({ nome: database.nome })
                                let embed = new Discord.EmbedBuilder()
                                    .setColor("#fff")
                                    .setDescription(`\`\`\`${database.desc}\`\`\`\n**💻 - Nome: ${database.nome}**\n**💎 - Preço: R$${database.valor}**\n**📦 - Estoque: ${database.estoque.length}**`)
                                    .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
              
                                await i.editReply({ embeds: [embed], components: [row,      new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                    .setCustomId('attmsg')
                                    .setLabel("Atualizar Mensagem")
                                    .setStyle(Discord.ButtonStyle.Primary),
                    
                                )], content: "" })

                            });
                        } else if (i.customId == "price") {
                            i.update({ content: "Envie o preço que deseja setar", embeds: [], components: [] })
                            const collector = inter.channel.createMessageCollector({ time: 60000 * 4 });

                            collector.on('collect', async m => {
                                let newPrice = m.content
                                collector.stop()
                                m.delete()
                                await produtos.updateOne({ nome: database.nome }, {
                                    $set: {
                                        valor: newPrice
                                    }
                                })

                                database = await produtos.findOne({ nome: database.nome })
                                let embed = new Discord.EmbedBuilder()
                                    .setColor("#fff")
                                    .setDescription(`\`\`\`${database.desc}\`\`\`\n**💻 - Nome: ${database.nome}**\n**💎 - Preço: R$${database.valor}**\n**📦 - Estoque: ${database.estoque.length}**`)
                                    .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
               
                                await i.editReply({ embeds: [embed], components: [row,      new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                    .setCustomId('attmsg')
                                    .setLabel("Atualizar Mensagem")
                                    .setStyle(Discord.ButtonStyle.Primary),
                    
                                )], content: "" })

                            });
                        } else if (i.customId == "estoque") {
                            let valores = database.estoque
                            let estoque = valores.map(valor => `-  ${valor}`).join("\n")
                            if (valores.length < 1) estoque = 'Não há estoque'
                            let embed = new Discord.EmbedBuilder()
                                .setColor("#fff")
                                .setDescription(`💎 Nome: ${database.nome}\n🛒 Quantidade de intens: ${valores.length}\n\`\`\`${estoque}\`\`\``)
                                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
                            let row = new Discord.ActionRowBuilder().addComponents(
                                new Discord.ButtonBuilder()
                                    .setCustomId('add')
                                    .setLabel("Adicionar estoque rapido")
                                    .setStyle(Discord.ButtonStyle.Secondary),
                                new Discord.ButtonBuilder()
                                    .setCustomId('add2')
                                    .setLabel("Adicionar estoque 1 a 1")
                                    .setStyle(Discord.ButtonStyle.Secondary),
                                new Discord.ButtonBuilder()
                                    .setCustomId('apagar')
                                    .setLabel("Apagar 1 Produto")
                                    .setStyle(Discord.ButtonStyle.Secondary),
                                new Discord.ButtonBuilder()
                                    .setCustomId('reset')
                                    .setLabel("Resetar Todos")
                                    .setStyle(Discord.ButtonStyle.Secondary),

                            )

                            i.update({ embeds: [embed], components: [row] })


                        } else if (i.customId == 'add') {
                            i.update({ content: "Envie todo o estoque, separando cada produto por linha", embeds: [], components: [] })
                            const filter = m => m.author.id == i.user.id;
                            const collector = i.channel.createMessageCollector({ filter, time: 600000 * 3, max: 1 });


                            collector.on('collect', async m => {

                                let contas = m.content
                                m.delete()
                                if (!contas) return
                                let alls = contas.split("\n")
                                for (let i = 0; i < alls.length; i++) {
                                    await produtos.updateOne({ nome: database.nome }, { $push: { estoque: alls[i] } })
                                }

                                database = await produtos.findOne({ nome: database.nome })
                                let valores = database.estoque
                                let estoque = valores.map(valor => `-  ${valor}`).join("\n")
                                if (valores.length < 1) estoque = 'Não há estoque'
                                let embed = new Discord.EmbedBuilder()
                                    .setColor("#fff")
                                    .setDescription(`💎 Nome: ${database.nome}\n🛒 Quantidade de intens: ${valores.length}\n\`\`\`${estoque}\`\`\``)
                                    .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
                                let row = new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                        .setCustomId('add')
                                        .setLabel("Adicionar estoque rapido")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                    new Discord.ButtonBuilder()
                                        .setCustomId('add2')
                                        .setLabel("Adicionar estoque 1 a 1")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                    new Discord.ButtonBuilder()
                                        .setCustomId('apagar')
                                        .setLabel("Apagar 1 Produto")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                    new Discord.ButtonBuilder()
                                        .setCustomId('reset')
                                        .setLabel("Resetar Todos")
                                        .setStyle(Discord.ButtonStyle.Secondary),

                                )

                                i.editReply({ embeds: [embed], components: [row] })

                            });



                        } else if (i.customId == 'add2') {
                            i.update({ content: "Envie o estoque 1 por vez, quando quiser terminar escreva '**finalizar**'", embeds: [], components: [] })
                            const filter = m => m.author.id == i.user.id;
                            const collector = i.channel.createMessageCollector({ filter, time: 600000 * 3 });


                            collector.on('collect', async m => {

                                let conta = m.content
                                m.delete()
                                if (conta.includes('finalizar')) {
                                    collector.stop()
                                    database = await produtos.findOne({ nome: database.nome })
                                    let valores = database.estoque
                                    let estoque = valores.map(valor => `-  ${valor}`).join("\n")
                                    if (valores.length < 1) estoque = 'Não há estoque'
                                    let embed = new Discord.EmbedBuilder()
                                        .setColor("#fff")
                                        .setDescription(`💎 Nome: ${database.nome}\n🛒 Quantidade de intens: ${valores.length}\n\`\`\`${estoque}\`\`\``)
                                        .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
                                    let row = new Discord.ActionRowBuilder().addComponents(
                                        new Discord.ButtonBuilder()
                                            .setCustomId('add')
                                            .setLabel("Adicionar estoque rapido")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                            .setCustomId('add2')
                                            .setLabel("Adicionar estoque 1 a 1")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                            .setCustomId('apagar')
                                            .setLabel("Apagar 1 Produto")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                            .setCustomId('reset')
                                            .setLabel("Resetar Todos")
                                            .setStyle(Discord.ButtonStyle.Secondary),

                                    )

                                    i.editReply({ embeds: [embed], components: [row] })
                                } else {

                                    await produtos.updateOne({ nome: database.nome }, { $push: { estoque: conta } })

                                }


                            });



                        } else if (i.customId == 'apagar') {

                            database = await produtos.findOne({ nome: database.nome })
                            let valores = database.estoque
                            let estoque = valores.map((valor, i) => `${i+1}  ${valor}`).join("\n")
                            if (valores.length < 1) return i.update({embeds:[],components:[],content:"Não há estoque"})
                            let embed = new Discord.EmbedBuilder()
                                .setColor("#fff")
                                .setDescription(`Envie o Numero da linha que deseja apagar\n\`\`\`${estoque}\`\`\``)
                                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
              

                            i.update({ embeds: [embed], components: [] })

                            const filter = m => m.author.id == i.user.id;
                            const collector = i.channel.createMessageCollector({ filter, time: 600000 * 3 });


                            collector.on('collect', async m => {
                                collector.stop()
                                let conta = Number(m.content) - 1
                                m.delete()
                                let stq = valores[conta]
                                if(!stq) return i.editReply({embeds:[],components:[],content:"Não existe essa linha!"})
                                let inx = valores.indexOf(stq)
                                if(inx < 0) return i.editReply({embeds:[],components:[],content:"Não existe essa linha!"})
                                let idx = valores.splice(inx,1)
                             
                                await produtos.updateOne({nome:database.nome},{$set:{estoque:valores}}).then( async ()=>{
                                    database = await produtos.findOne({ nome: database.nome })

                                    let valores = database.estoque
                                    let estoque = valores.map(valor => `-  ${valor}`).join("\n")
                                    if (valores.length < 1) estoque = 'Não há estoque'
                                    let embed = new Discord.EmbedBuilder()
                                        .setColor("#fff")
                                        .setDescription(`💎 Nome: ${database.nome}\n🛒 Quantidade de intens: ${valores.length}\n\`\`\`${estoque}\`\`\``)
                                        .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
                                    let row = new Discord.ActionRowBuilder().addComponents(
                                        new Discord.ButtonBuilder()
                                            .setCustomId('add')
                                            .setLabel("Adicionar estoque rapido")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                            .setCustomId('add2')
                                            .setLabel("Adicionar estoque 1 a 1")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                            .setCustomId('apagar')
                                            .setLabel("Apagar 1 Produto")
                                            .setStyle(Discord.ButtonStyle.Secondary),
                                        new Discord.ButtonBuilder()
                                            .setCustomId('reset')
                                            .setLabel("Resetar Todos")
                                            .setStyle(Discord.ButtonStyle.Secondary),
    
                                    )
    
                                    i.editReply({ embeds: [embed], components: [row],content:"" })
    
                                })

               

                            });



                        } else if (i.customId == 'reset') {
                            await produtos.updateOne({nome:database.nome},{$set:{estoque:[]}}).then( async ()=>{
                                database = await produtos.findOne({ nome: database.nome })

                                let valores = database.estoque
                                let estoque = valores.map(valor => `-  ${valor}`).join("\n")
                                if (valores.length < 1) estoque = 'Não há estoque'
                                let embed = new Discord.EmbedBuilder()
                                    .setColor("#fff")
                                    .setDescription(`💎 Nome: ${database.nome}\n🛒 Quantidade de intens: ${valores.length}\n\`\`\`${estoque}\`\`\``)
                                    .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
                                let row = new Discord.ActionRowBuilder().addComponents(
                                    new Discord.ButtonBuilder()
                                        .setCustomId('add')
                                        .setLabel("Adicionar estoque rapido")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                    new Discord.ButtonBuilder()
                                        .setCustomId('add2')
                                        .setLabel("Adicionar estoque 1 a 1")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                    new Discord.ButtonBuilder()
                                        .setCustomId('apagar')
                                        .setLabel("Apagar 1 Produto")
                                        .setStyle(Discord.ButtonStyle.Secondary),
                                    new Discord.ButtonBuilder()
                                        .setCustomId('reset')
                                        .setLabel("Resetar Todos")
                                        .setStyle(Discord.ButtonStyle.Secondary),

                                )

                                i.update({ embeds: [embed], components: [row] })

                            })

                        }
                    } else {
                        i.reply({ content: `Esse botão não é pra você!`, ephemeral: true });
                    }
                });
            })
        }

    }
}