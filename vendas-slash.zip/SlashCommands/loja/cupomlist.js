const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const us = require("../../models/cupom")
const { ComponentType } = require('discord.js');
module.exports = {
    name: 'cupomlist',
    description: 'Lista de cupons',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
 




    run: async (Client, inter) => {

        let database = await us.find()
        let produt = await database.map(val=>`Cupom ${val.nome} - \`${val.porcentagem}%\` - ${val.quantidade} restantes -  valor minimo pra uso R$${val.valormin||0} -  Produto que pode ser usado ${val.produto||"Todos os produtos"}`).join("\n") || "Não há cupons"

            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`${produt}`)
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
     

            inter.reply({ embeds: [embed] })
        
       

    }
}