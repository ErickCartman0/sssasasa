const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const produtos = require("../../models/produtos")
const { ComponentType } = require('discord.js');
module.exports = {
    name: 'del',
    description: 'Deleta um produto',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'name',
            description: 'Qual o nome do produto que deseja deletar ',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },

    ],




    run: async (Client, inter) => {

        let database = await produtos.findOne({ nome: inter.options.getString("name") })
        if (!database) {
            return inter.reply({ embeds: [new Discord.EmbedBuilder().setColor("#fff").setDescription("Produto não encontrado!").setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })] })
        } else {

            await produtos.deleteOne({nome:database.nome})
            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`💎 Nome: ${database.nome}\nProduto excluido com sucesso!`)
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
     

            inter.reply({ embeds: [embed] })

            let msgs = await    database.msgs
            msgs.forEach(async val=>{
                await Client.channels.cache.get(val.split("_")[0]).messages.fetch(val.split("_")[1]).then(msg=>{
                    msg.delete()
                }).catch(err=>{console.log(err)})
            })
        
        }

    }
}