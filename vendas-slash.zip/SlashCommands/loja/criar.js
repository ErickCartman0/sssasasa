const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const produtos = require("../../models/produtos")
module.exports = {
    name: 'criar',
    description: 'Sistema de criação de produtos',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores


       


    run: async (Client, inter) => {
        const modal = new ModalBuilder()
        .setCustomId(inter.id)
        .setTitle('Criar Produto');
    const name = new TextInputBuilder()
        .setCustomId('name')
        .setLabel("Qual o nome do produto?")
        .setPlaceholder("Ex: Bola de volei")
        .setStyle(TextInputStyle.Short);
        const desc = new TextInputBuilder()
        .setCustomId('desc')
        .setLabel("Qual a desc do produto?")
        .setPlaceholder("Ex: Bola para jogar volei")
        .setStyle(TextInputStyle.Paragraph);
        const valor = new TextInputBuilder()
        .setCustomId('price')
        .setLabel("Qual o valor do produto?")
        .setPlaceholder("PS: Sem R$ e valores quebrados deve se usar . ao invés de ,")
        .setStyle(TextInputStyle.Short);
        const tumb = new TextInputBuilder()
        .setCustomId('banner')
        .setLabel("Qual o banner do produto?")
        .setPlaceholder("Ex: https://imgur.com/image4354554.png")
        .setStyle(TextInputStyle.Short);

    modal.addComponents(new ActionRowBuilder().addComponents(name),new ActionRowBuilder().addComponents(desc),new ActionRowBuilder().addComponents(valor),new ActionRowBuilder().addComponents(tumb),);
    await inter.showModal(modal).then( async()=>{


const filter = i => i.customId == inter.id
const collector = await inter.awaitModalSubmit({ filter: i => i.user.id === inter.user.id, time: 1200000_000 })


let name = collector.fields.getTextInputValue('name');
let desc = collector.fields.getTextInputValue('desc');
let price = collector.fields.getTextInputValue('price');
let banner = collector.fields.getTextInputValue('banner');

let database = await produtos.findOne({nome:name})
if(!database) {
await produtos.create({nome:name,desc:desc,valor:price, banner:banner,type:1,estoque:[]})
collector.reply(`Produto **${name}** foi registrado com o valor \`R$${price}\`!`)
} else {
    collector.reply("Ja existe um produto com esse nome.")
}
})

    }
}