const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const cupom = require("../../models/cupom")
const { ComponentType } = require('discord.js');
const { database } = require('firebase-admin');
const produtos = require('../../models/cupom');
module.exports = {
    name: 'configcupom',
    description: 'Sistema de configurar cupom',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'name',
            description: 'Qual o nome do produto que deseja configurar ',
            type: Discord.ApplicationCommandOptionType.String,
            required: true
        },

    ],




    run: async (Client, inter) => {

        let database = await cupom.findOne({ nome: inter.options.getString("name") })
        if (!database) {
            return inter.reply({ embeds: [new Discord.EmbedBuilder().setColor("#fff").setDescription("Cupom não encontrado!").setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })] })
        } else {

            let embed = new Discord.EmbedBuilder()
            .setColor("#fff")
            .setDescription(`**💻 - Nome: ${database.nome}**\n**💎 - Usos Restantes: ${database.quantidade}**\n**❤ - Porcentagem: ${database.porcentagem}%**\n**💚 - Produto: ${database.produto||"Não definido"}**\n**💜 - Minimo para uso: R$${database.valormin}**`)
            .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
                 let row  =  new Discord.ActionRowBuilder().addComponents(
                    new Discord.ButtonBuilder()
                        .setCustomId('porcentagem')
                        .setLabel("Porcentagem")
                        .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                        .setCustomId('valor')
                        .setLabel("Min Valor")
                        .setStyle(Discord.ButtonStyle.Secondary),
                    new Discord.ButtonBuilder()
                        .setCustomId('quantidade')
                        .setLabel("Quantidade")
                        .setStyle(Discord.ButtonStyle.Secondary),
     
                    new Discord.ButtonBuilder()
                        .setCustomId('deletar')
                        .setLabel("deletar")
                        .setStyle(Discord.ButtonStyle.Danger),
    
                )

        
            await inter.reply({ embeds: [embed], components: [row] }).then(msg => {



                const collector = msg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 * 4 });

                collector.on('collect', async i => {
                    if (i.user.id === inter.user.id) {
                   if (i.customId == "porcentagem") {
                            i.update({ content: "Envie a Porcentagem que deseja setar", embeds: [], components: [] })
                            const collector = inter.channel.createMessageCollector({ time: 60000 * 4 });

                            collector.on('collect', async m => {
                                let newPocent = Number(m.content)
                                
                                collector.stop()
                                m.delete()
                              

                        
                            if (!newPocent) return i.editReply({ content: "Porcentagem invalida, 25% = 25",embeds:[],components:[] })

                            await produtos.updateOne({ nome: database.nome },{$set:{porcentagem:newPocent}})
                       

                                database = await produtos.findOne({ nome: database.nome })
                                let embed = new Discord.EmbedBuilder()
                                .setColor("#fff")
                                .setDescription(`**💻 - Nome: ${database.nome}**\n**💎 - Usos Restantes: ${database.quantidade}**\n**❤ - Porcentagem: ${database.porcentagem}%**\n**💚 - Produto: ${database.produto||"Não definido"}**\n**💜 - Minimo para uso: R$${database.valormin}**`)
                                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
             

                                await i.editReply({ embeds: [embed], components: [row], content: "" })

                            });

                        
                        } else      if (i.customId == "valor") {
                            i.update({ content: "Envie o valor que deseja setar", embeds: [], components: [] })
                            const collector = inter.channel.createMessageCollector({ time: 60000 * 4 });

                            collector.on('collect', async m => {
                                let newPocent = Number(m.content)
                                
                                collector.stop()
                                m.delete()
                              

                        
                            if (!newPocent) return i.editReply({ content: "valor invalido, R$25 = 25",embeds:[],components:[] })

                            await produtos.updateOne({ nome: database.nome },{$set:{valormin:newPocent}})
                       

                                database = await produtos.findOne({ nome: database.nome })
                                let embed = new Discord.EmbedBuilder()
                                .setColor("#fff")
                                .setDescription(`**💻 - Nome: ${database.nome}**\n**💎 - Usos Restantes: ${database.quantidade}**\n**❤ - Porcentagem: ${database.porcentagem}%**\n**💚 - Produto: ${database.produto||"Não definido"}**\n**💜 - Minimo para uso: R$${database.valormin}**`)
                                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })

                                await i.editReply({ embeds: [embed], components: [row], content: "" })

                            });

                        
                        } else      if (i.customId == "quantidade") {
                            i.update({ content: "Envie a quantidade que deseja setar", embeds: [], components: [] })
                            const collector = inter.channel.createMessageCollector({ time: 60000 * 4 });

                            collector.on('collect', async m => {
                                let newPocent = Number(m.content)
                                
                                collector.stop()
                                m.delete()
                              

                        
                            if (!newPocent) return i.editReply({ content: "valor invalido",embeds:[],components:[] })

                            await produtos.updateOne({ nome: database.nome },{$set:{quantidade:newPocent}})
                       

                                database = await produtos.findOne({ nome: database.nome })
                                let embed = new Discord.EmbedBuilder()
                                .setColor("#fff")
                                .setDescription(`**💻 - Nome: ${database.nome}**\n**💎 - Usos Restantes: ${database.quantidade}**\n**❤ - Porcentagem: ${database.porcentagem}%**\n**💚 - Produto: ${database.produto||"Não definido"}**\n**💜 - Minimo para uso: R$${database.valormin}**`)
                                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })

                                await i.editReply({ embeds: [embed], components: [row], content: "" })

                            });

                        
                        }else if (i.customId == 'apagar') {

                            database = await produtos.findOne({ nome: database.nome })
                            let valores = database.estoque
                            let estoque = valores.map((valor, i) => `${i+1}  ${valor}`).join("\n")
                            if (valores.length < 1) return i.update({embeds:[],components:[],content:"Não há estoque"})
                            let embed = new Discord.EmbedBuilder()
                            .setColor("#fff")
                            .setDescription(`**💻 - Nome: ${database.nome}**\n**💎 - Usos Restantes: ${database.quantidade}**\n**❤ - Porcentagem: ${database.porcentagem}%**\n**💚 - Produto: ${database.produto||"Não definido"}**\n**💜 - Minimo para uso: R$${database.valormin}**`)
                            .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })

                            i.update({ embeds: [embed], components: [] })

                            const filter = m => m.author.id == i.user.id;
                            const collector = i.channel.createMessageCollector({ filter, time: 600000 * 3 });


                            collector.on('collect', async m => {
                                collector.stop()
                                let conta = Number(m.content) - 1
                                m.delete()
                                let stq = valores[conta]
                                if(!stq) return i.editReply({embeds:[],components:[],content:"Não existe essa linha!"})
                                let inx = valores.indexOf(stq)
                                if(inx < 0) return i.editReply({embeds:[],components:[],content:"Não existe essa linha!"})
                                let idx = valores.splice(inx,1)
                             
                                await produtos.updateOne({nome:database.nome},{$set:{estoque:valores}}).then( async ()=>{
                                    database = await produtos.findOne({ nome: database.nome })
                      
                                    i.editReply({ embeds: [], components: [],content:"Cupom deletado" })

    
                                })

               

                            });



                        } 
                    } else {
                        i.reply({ content: `Esse botão não é pra você!`, ephemeral: true });
                    }
                });
            })
        }

    }
}