const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const us = require("../../models/User")
const { ComponentType } = require('discord.js');
const config = require("../../config.json")
module.exports = {
    name: 'permadd',
    description: 'Add perm a um user',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
    options: [

        {
            name: 'user',
            description: 'Usuario que deseja add',
            type: Discord.ApplicationCommandOptionType.User,
            required: true
        },

    ],




    run: async (Client, inter) => {
        if(inter.user.id==config.ownerid) {
        let user = inter.options.getUser("user") 
        let database = await us.findOne({userID:user.id})
        if(!database) await us.create({ userID: user.id, valor: 0, produtos: 0, perm: false, termos: false })
        await us.updateOne({userID:user.id},{$set:{perm:true}})
            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`Perm adicionada com sucesso!`)
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
     

            inter.reply({ embeds: [embed] })
        
        } else {
            return inter.reply("Você não tem perm para ver isso")
        }

    }
}