const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const us = require("../../models/User")
const { ComponentType } = require('discord.js');
module.exports = {
    name: 'permlist',
    description: 'Lista de quem tem perm',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores
 




    run: async (Client, inter) => {

        let database = await us.find({perm:true})
        let produt = await database.map(val=>`User -  <@${val.userID}>`).join("\n") || "Não há membros"

            let embed = new Discord.EmbedBuilder()
                .setColor("#fff")
                .setDescription(`${produt}`)
                .setAuthor({ name: inter.user.username, iconURL: inter.user.avatarURL() })
     

            inter.reply({ embeds: [embed] })
        
       

    }
}