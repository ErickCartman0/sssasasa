const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const { QuickDB } = require("quick.db");
const db = new QuickDB();

module.exports = {
    name: 'botconfig',
    description: 'Configura o bot',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores

       


    run: async (Client, inter) => {
        let colorembed = await db.get("colorembed") || "#fff"

        let embed = new EmbedBuilder()
        .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
        .setDescription(`Nome do bot - \`${Client.user.username}\`\nAvatar do bot - \`${Client.user.avatarURL() || 'Não tem avatar'}\`\nCor das Embeds - \`${colorembed}\``)    
        .setColor("#FFF")



        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
            .setCustomId('nome')
            .setLabel('Setar Nome')
            .setStyle(Discord.ButtonStyle.Secondary),
            new Discord.ButtonBuilder()
            .setCustomId('avatar')
            .setLabel('Setar Avatar')
            .setStyle(Discord.ButtonStyle.Secondary),
            new Discord.ButtonBuilder()
            .setCustomId('embeds')
            .setLabel('Embeds')
            .setStyle(Discord.ButtonStyle.Secondary),
            new Discord.ButtonBuilder()
            .setCustomId('status')
            .setLabel('Status')
            .setStyle(Discord.ButtonStyle.Secondary),
      
        )

        inter.reply({embeds:[embed],components:[row]}).then(msg=>{

            const filter = i =>  i.user.id === inter.user.id ;

            const collector = msg.createMessageComponentCollector({ filter, time: 60000*4 });
            
            collector.on('collect', async i => {
                if(i.customId == 'nome') {
                    i.update({content:"Envie o nome abaixo", components:[], embeds:[]})
                    const filter = m => m.author.id == inter.user.id
                    const collector = i.channel.createMessageCollector({ filter, time: 60000 });
                    collector.on('collect',async m => {
                        let nome = m.content
                        m.delete()
                        collector.stop()
                        if(!nome) return i.editReply({content:"Envie um nome valido",embeds:[]})
                        if(nome < 30) return i.editReply({content:"Nome deve ser menor que 30 caracteres",embeds:[]})
    Client.user.setUsername(nome)
  .then(user => console.log(`Nome alterado para ${user.username}`))
  .catch(err=>{console.log(`Erro ao alterar para ${user.username}`)});
                        let colorembed = await db.get("colorembed") || "#fff"

                        let embed = new EmbedBuilder()
                        .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
                        .setDescription(`Nome do bot - \`${Client.user.username}\`\nAvatar do bot - \`${Client.user.avatarURL() || 'Não tem avatar'}\`\nCor das Embeds - \`${colorembed}\``)    
                        .setColor("#FFF")
                
                
                
                        let row = new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                            .setCustomId('nome')
                            .setLabel('Setar Nome')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('avatar')
                            .setLabel('Setar Avatar')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('embeds')
                            .setLabel('Embeds')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('status')
                            .setLabel('Status')
                            .setStyle(Discord.ButtonStyle.Secondary),
                      
                        )
                
                        i.editReply({embeds:[embed],components:[row]})
                    })
                } else        if(i.customId == 'avatar') {
                    i.update({content:"Envie a URL do avatar abaixo", components:[], embeds:[]})
                    const filter = m => m.author.id == inter.user.id
                    const collector = i.channel.createMessageCollector({ filter, time: 60000 });
                    collector.on('collect',async m => {
                        let url = m.content
                        m.delete()
                        collector.stop()
                        if(!url) return i.editReply({content:"Envie uma url valida",embeds:[]})
             
    Client.user.setAvatar(url)
  .then(user => console.log(`Avatar alterado `))
  .catch(err=>{console.log(`Erro ao alterar meu avatar`)});
                        let colorembed = await db.get("colorembed") || "#fff"

                        let embed = new EmbedBuilder()
                        .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
                        .setDescription(`Nome do bot - \`${Client.user.username}\`\nAvatar do bot - \`${Client.user.avatarURL() || 'Não tem avatar'}\`\nCor das Embeds - \`${colorembed}\``)    
                        .setColor("#FFF")
                
                
                
                        let row = new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                            .setCustomId('nome')
                            .setLabel('Setar Nome')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('avatar')
                            .setLabel('Setar Avatar')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('embeds')
                            .setLabel('Embeds')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('status')
                            .setLabel('Status')
                            .setStyle(Discord.ButtonStyle.Secondary),
                      
                        )
                
                        i.editReply({embeds:[embed],components:[row]})
                    })
                } else        if(i.customId == 'embeds') {
                    i.update({content:"Envie a hexcolor da embed abaixo\n> Exemplo - #fff ( branco )", components:[], embeds:[]})
                    const filter = m => m.author.id == inter.user.id
                    const collector = i.channel.createMessageCollector({ filter, time: 60000 });
                    collector.on('collect',async m => {
                        let hex = m.content
                        m.delete()
                        collector.stop()
                        if(!hex) return i.editReply({content:"Envie uma hex valida",embeds:[]})
                        await db.set("colorembed",hex)

                        let colorembed = await db.get("colorembed") || "#fff"

                        let embed = new EmbedBuilder()
                        .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
                        .setDescription(`Nome do bot - \`${Client.user.username}\`\nAvatar do bot - \`${Client.user.avatarURL() || 'Não tem avatar'}\`\nCor das Embeds - \`${colorembed}\``)    
                        .setColor("#FFF")
                
                
                
                        let row = new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                            .setCustomId('nome')
                            .setLabel('Setar Nome')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('avatar')
                            .setLabel('Setar Avatar')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('embeds')
                            .setLabel('Embeds')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('status')
                            .setLabel('Status')
                            .setStyle(Discord.ButtonStyle.Secondary),
                      
                        )
                
                        i.editReply({embeds:[embed],components:[row]})
                    })
                } else if(i.customId == 'status') {

                    i.update({embeds:[new Discord.EmbedBuilder().setColor("#fff").setDescription("Selecione qual o TYPE do status")],components:[
                        new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                            .setCustomId("0_status2")
                            .setLabel("Playing")
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId("2_status2")
                            .setLabel("Listening")
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId("3_status2")
                            .setLabel("Watching")
                            .setStyle(Discord.ButtonStyle.Secondary),
                        )
                    ]})

                } else        if(i.customId.includes('status2')) {

                    let type = i.customId.split("_")[0]

                    i.update({content:"Envie o status do bot e será setado como", components:[], embeds:[]})
                    const filter = m => m.author.id == inter.user.id
                    const collector = i.channel.createMessageCollector({ filter, time: 60000 });
                    collector.on('collect',async m => {
                        let sts = m.content
                        m.delete()
                        collector.stop()
                        if(!sts) return i.editReply({content:"Envie um status valido",embeds:[]})
                        
                        Client.user.setActivity(String(sts), { name: String(sts) , type: Number(type) })
                        let colorembed = await db.get("colorembed") || "#fff"

                        let embed = new EmbedBuilder()
                        .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
                        .setDescription(`Nome do bot - \`${Client.user.username}\`\nAvatar do bot - \`${Client.user.avatarURL() || 'Não tem avatar'}\`\nCor das Embeds - \`${colorembed}\``)    
                        .setColor("#FFF")
                
                
                
                        let row = new Discord.ActionRowBuilder().addComponents(
                            new Discord.ButtonBuilder()
                            .setCustomId('nome')
                            .setLabel('Setar Nome')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('avatar')
                            .setLabel('Setar Avatar')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('embeds')
                            .setLabel('Embeds')
                            .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                            .setCustomId('status')
                            .setLabel('Status')
                            .setStyle(Discord.ButtonStyle.Secondary),
                      
                        )
                
                        i.editReply({embeds:[embed],content:"",components:[row]})
                    })
                } 
            });
        })

        


    }
}