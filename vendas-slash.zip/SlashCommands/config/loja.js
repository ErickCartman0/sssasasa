const Discord = require('discord.js')
const ms = require("ms")
const { ActionRowBuilder, Events, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const loja = require('../../models/loja')
module.exports = {
    name: 'lojaconfig',
    description: 'Configura sistema de loja',
    Globally: false, // Altere para [true] caso queira que o bot execute este comando em todos os servidores

       


    run: async (Client, inter) => {
        let config = await loja.findOne({guildID:inter.guild.id,})

        if(!config) {
            await loja.create({guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null})
            config =await loja.findOne({guildID:inter.guild.id})
        }
        let cdloja = {
            label:"Desativar Loja",
            customId:"false",
            style:Discord.ButtonStyle.Danger,
            status:"ativa"
        }
        if(config.loja =='false') {
            cdloja.label = 'Ativar Loja'
            cdloja.customId = 'true',
            cdloja.style=Discord.ButtonStyle.Success,
            cdloja.status = "desativada"
        }
        let publica = Client.channels.cache.get(config.publica) || "`Não Setada`"
        let privada = Client.channels.cache.get(config.privada) || "`Não Setada`"
        let carrinhos = Client.channels.cache.get(config.carrinhos) || "`Não Setada`"

        let embed = new EmbedBuilder()
        .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
        .setDescription(`Status da loja:\n> On/Off - \`${cdloja['status']}\`\n> Logs Publica - ${publica}\n> Logs Privada - ${privada}\n> Categoria Carrinhos - ${carrinhos}`)    
        .setColor("#FFF")

  

        let row = new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
            .setCustomId('pag1_logspublica')
            .setLabel('Logs Publica')
            .setStyle(Discord.ButtonStyle.Secondary),
            new Discord.ButtonBuilder()
            .setCustomId('pag1_logsprivada')
            .setLabel('Logs Privada')
            .setStyle(Discord.ButtonStyle.Secondary),
            new Discord.ButtonBuilder()
            .setCustomId('pag1_categoria')
            .setLabel('Categoria Carrinho')
            .setStyle(Discord.ButtonStyle.Secondary),
            new Discord.ButtonBuilder()
            .setCustomId('termos')
            .setLabel('Termos')
            .setStyle(Discord.ButtonStyle.Secondary),
            new Discord.ButtonBuilder()
            .setCustomId('acesstoken')
            .setLabel('Acess Token')
            .setStyle(Discord.ButtonStyle.Secondary),
        )

        inter.reply({embeds:[embed],components:[new Discord.ActionRowBuilder().addComponents(
            new Discord.ButtonBuilder()
            .setCustomId(cdloja['customId'])
            .setLabel(cdloja['label'])
            .setStyle(cdloja['style'])),row]}).then(msg=>{

            const filter = i =>  i.user.id === inter.user.id ;

            const collector = msg.createMessageComponentCollector({ filter, time: 60000*4 });
            
            collector.on('collect', async i => {
                if(i.customId == 'pag0') {
                    let config = await loja.findOne({guildID:inter.guild.id,})

                    if(!config) {
                        await loja.create({guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null})
                        config =await loja.findOne({guildID:inter.guild.id})
                    }
                    let cdloja = {
                        label:"Desativar Loja",
                        customId:"false",
                        style:Discord.ButtonStyle.Danger,
                        status:"ativa"
                    }
                    if(config.loja =='false') {
                        cdloja.label = 'Ativar Loja'
                        cdloja.customId = 'true',
                        cdloja.style=Discord.ButtonStyle.Success,
                        cdloja.status = "desativada"
                    }
                    let publica = Client.channels.cache.get(config.publica) || "`Não Setada`"
                    let privada = Client.channels.cache.get(config.privada) || "`Não Setada`"
                    let carrinhos = Client.channels.cache.get(config.carrinhos) || "`Não Setada`"
            
                    let embed = new EmbedBuilder()
                    .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
                    .setDescription(`Status da loja:\n> On/Off - \`${cdloja['status']}\`\n> Logs Publica - ${publica}\n> Logs Privada - ${privada}\n> Categoria Carrinhos - ${carrinhos}`)    
                    .setColor("#FFF")
            
              
            
                    i.update({embeds:[embed],components:[new Discord.ActionRowBuilder().addComponents(
                        new Discord.ButtonBuilder()
                        .setCustomId(cdloja['customId'])
                        .setLabel(cdloja['label'])
                        .setStyle(cdloja['style'])),row]})
                } else 
   if(i.customId == 'true' || i.customId == 'false') {
   await loja.updateOne({guildID:inter.guild.id},{$set:{ loja: i.customId}})





    let config = await loja.findOne({guildID:inter.guild.id})

    if(!config) {
        await loja.create({guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null})
        config =await loja.findOne({guildID:inter.guild.id})
    }
    let cdloja = {
        label:"Desativar Loja",
        customId:"false",
        style:Discord.ButtonStyle.Danger,
        status:"ativa"
    }
    if(config.loja =='false') {
        cdloja.label = 'Ativar Loja'
        cdloja.customId = 'true',
        cdloja.style=Discord.ButtonStyle.Success,
        cdloja.status = "desativada"
    }
    let publica = Client.channels.cache.get(config.publica) || "`Não Setada`"
    let privada = Client.channels.cache.get(config.privada) || "`Não Setada`"
    let carrinhos = Client.channels.cache.get(config.carrinhos) || "`Não Setada`"

    let embed = new EmbedBuilder()
    .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
    .setDescription(`Status da loja:\n> On/Off - \`${cdloja['status']}\`\n> Logs Publica - ${publica}\n> Logs Privada - ${privada}\n> Categoria Carrinhos - ${carrinhos}`)    
    .setColor("#FFF")




    i.update({embeds:[embed],components:[new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
        .setCustomId(cdloja['customId'])
        .setLabel(cdloja['label'])
 
        .setStyle(cdloja['style'])),row]})
   } else if(i.customId.includes("pag1_")) {
    let type = i.customId.split("_")[1]
    let embed = new EmbedBuilder()
    .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
    .setDescription(`Selecione o que deseja fazer`)    
    .setColor("#FFF")



    let row = new Discord.ActionRowBuilder().addComponents(
        new Discord.ButtonBuilder()
        .setCustomId(`pag2_${type}`)
        .setLabel('Setar')
        .setStyle(Discord.ButtonStyle.Secondary),
        new Discord.ButtonBuilder()
        .setCustomId(`pag3_${type}`)
        .setLabel('Resetar')
        .setStyle(Discord.ButtonStyle.Danger),

        new Discord.ButtonBuilder()
        .setCustomId(`pag0`)
        .setLabel('Voltar')
        .setStyle(Discord.ButtonStyle.Primary),
    )
    i.update({embeds:[embed],components:[row]})
   } else if(i.customId.includes("pag2_")) {

    let type = i.customId.split("_")[1]
    let embed = new EmbedBuilder()
    .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
    .setDescription(`Mencione o canal que deseja setar`)    
    .setColor("#FFF")

    i.update({embeds:[embed],components:[]})
    const filter = m => m.author.id == inter.user.id
    const collector = i.channel.createMessageCollector({ filter, time: 60000 });
    
    collector.on('collect',async m => {
       let channel = m.mentions.channels.first() || Client.channels.cache.get(m.content)
       m.delete()
       collector.stop()
       if(!channel) return i.editReply({content:"Canal invalido",embeds:[]})

       if(type == 'logspublica') {
        await loja.updateOne({guildID:inter.guild.id},{$set:{ publica:channel.id}})
       } else    if(type == 'logsprivada') {
        await loja.updateOne({guildID:inter.guild.id},{$set:{ privada:channel.id}})
       } else    if(type == 'categoria') {
        await loja.updateOne({guildID:inter.guild.id},{$set:{ carrinhos:channel.id}})
       }
       let config = await loja.findOne({guildID:inter.guild.id,})

       if(!config) {
           await loja.create({guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null})
           config =await loja.findOne({guildID:inter.guild.id})
       }
       let cdloja = {
           label:"Desativar Loja",
           customId:"false",
           style:Discord.ButtonStyle.Danger,
           status:"ativa"
       }
       if(config.loja =='false') {
           cdloja.label = 'Ativar Loja'
           cdloja.customId = 'true',
           cdloja.style=Discord.ButtonStyle.Success,
           cdloja.status = "desativada"
       }
       let publica = Client.channels.cache.get(config.publica) || "`Não Setada`"
       let privada = Client.channels.cache.get(config.privada) || "`Não Setada`"
       let carrinhos = Client.channels.cache.get(config.carrinhos) || "`Não Setada`"
   
       let embed = new EmbedBuilder()
       .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
       .setDescription(`Status da loja:\n> On/Off - \`${cdloja['status']}\`\n> Logs Publica - ${publica}\n> Logs Privada - ${privada}\n> Categoria Carrinhos - ${carrinhos}`)    
       .setColor("#FFF")
   
   
   
   
       i.editReply({embeds:[embed],components:[new Discord.ActionRowBuilder().addComponents(
           new Discord.ButtonBuilder()
           .setCustomId(cdloja['customId'])
           .setLabel(cdloja['label'])
           .setStyle(cdloja['style'])),row]})


    });

   } else if(i.customId.includes("pag3_")) {

    let type = i.customId.split("_")[1]
    if(type == 'logspublica') {
        await loja.updateOne({guildID:inter.guild.id},{$set:{ publica:null}})
       } else    if(type == 'logsprivada') {
        await loja.updateOne({guildID:inter.guild.id},{$set:{ privada:null}})
       } else    if(type == 'categoria') {
        await loja.updateOne({guildID:inter.guild.id},{$set:{ carrinhos:null}})
       }
       let config = await loja.findOne({guildID:inter.guild.id,})

       if(!config) {
           await loja.create({guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null})
           config =await loja.findOne({guildID:inter.guild.id})
       }
       let cdloja = {
           label:"Desativar Loja",
           customId:"false",
           style:Discord.ButtonStyle.Danger,
           status:"ativa"
       }
       if(config.loja =='false') {
           cdloja.label = 'Ativar Loja'
           cdloja.customId = 'true',
           cdloja.style=Discord.ButtonStyle.Success,
           cdloja.status = "desativada"
       }
       let publica = Client.channels.cache.get(config.publica) || "`Não Setada`"
       let privada = Client.channels.cache.get(config.privada) || "`Não Setada`"
       let carrinhos = Client.channels.cache.get(config.carrinhos) || "`Não Setada`"
   
       let embed = new EmbedBuilder()
       .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
       .setDescription(`Status da loja:\n> On/Off - \`${cdloja['status']}\`\n> Logs Publica - ${publica}\n> Logs Privada - ${privada}\n> Categoria Carrinhos - ${carrinhos}`)    
       .setColor("#FFF")
   
   
   
   
       i.update({embeds:[embed],components:[new Discord.ActionRowBuilder().addComponents(
           new Discord.ButtonBuilder()
           .setCustomId(cdloja['customId'])
           .setLabel(cdloja['label'])
           .setStyle(cdloja['style'])),row]})
   } else if(i.customId =="termos") {


    let embed = new EmbedBuilder()
    .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
    .setDescription(`Envie os termos abaixo`)    
    .setColor("#FFF")

    i.update({embeds:[embed],components:[]})
    const filter = m => m.author.id == inter.user.id
    const collector = i.channel.createMessageCollector({ filter, time: 60000 });
    
    collector.on('collect',async m => {
       let termos = m.content
       m.delete()
       collector.stop()
       if(!termos) return i.editReply({content:"Envie um termo valido",embeds:[]})
       if(termos < 1500) return i.editReply({content:"Termos deve ser menor que 1500 caracteres",embeds:[]})

        await loja.updateOne({guildID:inter.guild.id},{$set:{ termos:termos}})
       
       let config = await loja.findOne({guildID:inter.guild.id,})

       if(!config) {
           await loja.create({guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null})
           config =await loja.findOne({guildID:inter.guild.id})
       }
       let cdloja = {
           label:"Desativar Loja",
           customId:"false",
           style:Discord.ButtonStyle.Danger,
           status:"ativa"
       }
       if(config.loja =='false') {
           cdloja.label = 'Ativar Loja'
           cdloja.customId = 'true',
           cdloja.style=Discord.ButtonStyle.Success,
           cdloja.status = "desativada"
       }
       let publica = Client.channels.cache.get(config.publica) || "`Não Setada`"
       let privada = Client.channels.cache.get(config.privada) || "`Não Setada`"
       let carrinhos = Client.channels.cache.get(config.carrinhos) || "`Não Setada`"
   
       let embed = new EmbedBuilder()
       .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
       .setDescription(`Status da loja:\n> On/Off - \`${cdloja['status']}\`\n> Logs Publica - ${publica}\n> Logs Privada - ${privada}\n> Categoria Carrinhos - ${carrinhos}`)    
       .setColor("#FFF")
   
   
   
   
       i.editReply({embeds:[embed],components:[new Discord.ActionRowBuilder().addComponents(
           new Discord.ButtonBuilder()
           .setCustomId(cdloja['customId'])
           .setLabel(cdloja['label'])
           .setStyle(cdloja['style'])),row]})


    });

   }  else if(i.customId =="acesstoken") {


    let embed = new EmbedBuilder()
    .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
    .setDescription(`Envie o acess token abaixo`)    
    .setColor("#FFF")

    i.update({embeds:[embed],components:[]})
    const filter = m => m.author.id == inter.user.id
    const collector = i.channel.createMessageCollector({ filter, time: 60000 });
    
    collector.on('collect',async m => {
       let acesstoken = m.content
       m.delete()
       collector.stop()
       if(!acesstoken) return i.editReply({content:"Envie um acess token valido",embeds:[]})
       if(acesstoken < 1500) return i.editReply({content:"Esse acess token me parece invalido",embeds:[]})

        await loja.updateOne({guildID:inter.guild.id},{$set:{ acesstoken:acesstoken}})
       
       let config = await loja.findOne({guildID:inter.guild.id,})

       if(!config) {
           await loja.create({guildID:inter.guild.id,loja:true,publica:null,privada:null,carrinhos:null,termos:"Sem termos",acesstoken:null})
           config =await loja.findOne({guildID:inter.guild.id})
       }
       let cdloja = {
           label:"Desativar Loja",
           customId:"false",
           style:Discord.ButtonStyle.Danger,
           status:"ativa"
       }
       if(config.loja =='false') {
           cdloja.label = 'Ativar Loja'
           cdloja.customId = 'true',
           cdloja.style=Discord.ButtonStyle.Success,
           cdloja.status = "desativada"
       }
       let publica = Client.channels.cache.get(config.publica) || "`Não Setada`"
       let privada = Client.channels.cache.get(config.privada) || "`Não Setada`"
       let carrinhos = Client.channels.cache.get(config.carrinhos) || "`Não Setada`"
   
       let embed = new EmbedBuilder()
       .setAuthor({name:inter.user.username, iconURL:inter.user.avatarURL()})
       .setDescription(`Status da loja:\n> On/Off - \`${cdloja['status']}\`\n> Logs Publica - ${publica}\n> Logs Privada - ${privada}\n> Categoria Carrinhos - ${carrinhos}`)    
       .setColor("#FFF")
   
   
   
   
       i.editReply({embeds:[embed],components:[new Discord.ActionRowBuilder().addComponents(
           new Discord.ButtonBuilder()
           .setCustomId(cdloja['customId'])
           .setLabel(cdloja['label'])
           .setStyle(cdloja['style'])),row]})


    });

   }
            });
        })

        


    }
}